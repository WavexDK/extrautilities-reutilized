package net.wavedk.extrautilitiesreutilized.item;

import net.minecraft.world.item.Item;

public class SpeedUpgradeItem extends Item {
	public SpeedUpgradeItem(Item.Properties properties) {
		super(properties.stacksTo(4));
	}
}