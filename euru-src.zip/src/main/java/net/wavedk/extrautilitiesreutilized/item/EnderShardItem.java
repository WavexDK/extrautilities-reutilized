package net.wavedk.extrautilitiesreutilized.item;

import net.wavedk.extrautilitiesreutilized.procedures.EnderShardPropertyValueProviderProcedure;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.client.renderer.item.properties.numeric.RangeSelectItemModelProperty;
import net.minecraft.client.multiplayer.ClientLevel;

import javax.annotation.Nullable;

import com.mojang.serialization.MapCodec;

public class EnderShardItem extends Item {
	public EnderShardItem(Item.Properties properties) {
		super(properties.stacksTo(8));
	}

	public record CountProperty() implements RangeSelectItemModelProperty {
		public static final MapCodec<CountProperty> MAP_CODEC = MapCodec.unit(new CountProperty());

		@Override
		public float get(ItemStack itemStackToRender, @Nullable ClientLevel clientWorld, @Nullable LivingEntity entity, int seed) {
			return (float) EnderShardPropertyValueProviderProcedure.execute(itemStackToRender);
		}

		@Override
		public MapCodec<CountProperty> type() {
			return MAP_CODEC;
		}
	}
}