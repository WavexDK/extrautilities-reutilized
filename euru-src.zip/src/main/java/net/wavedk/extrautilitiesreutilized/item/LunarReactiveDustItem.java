package net.wavedk.extrautilitiesreutilized.item;

import net.minecraft.world.item.Item;

public class LunarReactiveDustItem extends Item {
	public LunarReactiveDustItem(Item.Properties properties) {
		super(properties);
	}
}