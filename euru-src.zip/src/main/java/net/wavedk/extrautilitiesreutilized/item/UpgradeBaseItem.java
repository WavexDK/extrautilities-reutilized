package net.wavedk.extrautilitiesreutilized.item;

import net.minecraft.world.item.Item;

public class UpgradeBaseItem extends Item {
	public UpgradeBaseItem(Item.Properties properties) {
		super(properties.stacksTo(16));
	}
}