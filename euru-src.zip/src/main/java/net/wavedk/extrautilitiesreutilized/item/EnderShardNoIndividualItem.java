package net.wavedk.extrautilitiesreutilized.item;

import net.minecraft.world.item.Item;

public class EnderShardNoIndividualItem extends Item {
	public EnderShardNoIndividualItem(Item.Properties properties) {
		super(properties.stacksTo(8));
	}
}