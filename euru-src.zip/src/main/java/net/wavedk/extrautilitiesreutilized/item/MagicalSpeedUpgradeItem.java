package net.wavedk.extrautilitiesreutilized.item;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;

public class MagicalSpeedUpgradeItem extends Item {
	public MagicalSpeedUpgradeItem(Item.Properties properties) {
		super(properties.stacksTo(16));
	}

	@Override
	public boolean isFoil(ItemStack itemstack) {
		return true;
	}
}