/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.wavedk.extrautilitiesreutilized.init;

import net.wavedk.extrautilitiesreutilized.EuruMod;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.Registries;

public class EuruModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, EuruMod.MODID);
	public static final DeferredHolder<CreativeModeTab, CreativeModeTab> EURU = REGISTRY.register("euru",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.euru.euru")).icon(() -> new ItemStack(EuruModBlocks.ANGEL_BLOCK.get())).displayItems((parameters, tabData) -> {
				tabData.accept(EuruModBlocks.SURVIVAL_GENERATOR.get().asItem());
				tabData.accept(EuruModBlocks.RESONATOR.get().asItem());
				tabData.accept(EuruModBlocks.CHUNK_LOADER_TESTER.get().asItem());
				tabData.accept(EuruModBlocks.MACHINE_BLOCK.get().asItem());
				tabData.accept(EuruModBlocks.ANGEL_BLOCK.get().asItem());
				tabData.accept(EuruModBlocks.GILDED_OBSIDIAN.get().asItem());
				tabData.accept(EuruModBlocks.CHUNK_LOADER.get().asItem());
				tabData.accept(EuruModBlocks.SOLAR_PANEL.get().asItem());
				tabData.accept(EuruModBlocks.LUNAR_PANEL.get().asItem());
				tabData.accept(EuruModItems.MAGICAL_SPEED_UPGRADE.get());
				tabData.accept(EuruModItems.SPEED_UPGRADE.get());
				tabData.accept(EuruModItems.UPGRADE_BASE.get());
				tabData.accept(EuruModItems.GP_SCANNER.get());
				tabData.accept(EuruModItems.LUNAR_REACTIVE_DUST.get());
				tabData.accept(EuruModItems.NUGGETO_EXPERIENCE.get());
				tabData.accept(EuruModItems.RESONATING_REDSTONE_CRYSTAL.get());
				tabData.accept(EuruModItems.GLASS_CUTTER.get());
				tabData.accept(EuruModItems.ENDER_SHARD.get());
				tabData.accept(EuruModItems.ENDER_SHARD_NO_INDIVIDUAL.get());
			}).build());
}