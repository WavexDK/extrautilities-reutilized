/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.wavedk.extrautilitiesreutilized.init;

import net.wavedk.extrautilitiesreutilized.item.*;
import net.wavedk.extrautilitiesreutilized.block.SolarPanelBlock;
import net.wavedk.extrautilitiesreutilized.block.LunarPanelBlock;
import net.wavedk.extrautilitiesreutilized.block.ChunkLoaderTesterBlock;
import net.wavedk.extrautilitiesreutilized.EuruMod;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.client.event.RegisterRangeSelectItemModelPropertyEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.api.distmarker.Dist;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;
import net.minecraft.resources.ResourceLocation;

import java.util.function.Function;

public class EuruModItems {
	public static final DeferredRegister.Items REGISTRY = DeferredRegister.createItems(EuruMod.MODID);
	public static final DeferredItem<Item> SOLAR_PANEL;
	public static final DeferredItem<Item> GP_SCANNER;
	public static final DeferredItem<Item> LUNAR_PANEL;
	public static final DeferredItem<Item> RESONATOR;
	public static final DeferredItem<Item> UPGRADE_BASE;
	public static final DeferredItem<Item> SPEED_UPGRADE;
	public static final DeferredItem<Item> RESONATING_REDSTONE_CRYSTAL;
	public static final DeferredItem<Item> ENDER_SHARD;
	public static final DeferredItem<Item> GLASS_CUTTER;
	public static final DeferredItem<Item> CHUNK_LOADER;
	public static final DeferredItem<Item> MAGICAL_SPEED_UPGRADE;
	public static final DeferredItem<Item> MACHINE_BLOCK;
	public static final DeferredItem<Item> LUNAR_REACTIVE_DUST;
	public static final DeferredItem<Item> SURVIVAL_GENERATOR;
	public static final DeferredItem<Item> CHUNK_LOADER_TESTER;
	public static final DeferredItem<Item> GILDED_OBSIDIAN;
	public static final DeferredItem<Item> NUGGETO_EXPERIENCE;
	public static final DeferredItem<Item> ANGEL_BLOCK;
	public static final DeferredItem<Item> ENDER_SHARD_NO_INDIVIDUAL;
	static {
		SOLAR_PANEL = register("solar_panel", properties -> new SolarPanelBlock.Item(properties.stacksTo(16)));
		GP_SCANNER = register("gp_scanner", GPScannerItem::new);
		LUNAR_PANEL = register("lunar_panel", properties -> new LunarPanelBlock.Item(properties.stacksTo(16)));
		RESONATOR = block(EuruModBlocks.RESONATOR);
		UPGRADE_BASE = register("upgrade_base", UpgradeBaseItem::new);
		SPEED_UPGRADE = register("speed_upgrade", SpeedUpgradeItem::new);
		RESONATING_REDSTONE_CRYSTAL = register("resonating_redstone_crystal", ResonatingRedstoneCrystalItem::new);
		ENDER_SHARD = register("ender_shard", EnderShardItem::new);
		GLASS_CUTTER = register("glass_cutter", GlassCutterItem::new);
		CHUNK_LOADER = block(EuruModBlocks.CHUNK_LOADER, new Item.Properties().stacksTo(1));
		MAGICAL_SPEED_UPGRADE = register("magical_speed_upgrade", MagicalSpeedUpgradeItem::new);
		MACHINE_BLOCK = block(EuruModBlocks.MACHINE_BLOCK);
		LUNAR_REACTIVE_DUST = register("lunar_reactive_dust", LunarReactiveDustItem::new);
		SURVIVAL_GENERATOR = block(EuruModBlocks.SURVIVAL_GENERATOR);
		CHUNK_LOADER_TESTER = register("chunk_loader_tester", ChunkLoaderTesterBlock.Item::new);
		GILDED_OBSIDIAN = block(EuruModBlocks.GILDED_OBSIDIAN);
		NUGGETO_EXPERIENCE = register("nuggeto_experience", NuggetoExperienceItem::new);
		ANGEL_BLOCK = block(EuruModBlocks.ANGEL_BLOCK);
		ENDER_SHARD_NO_INDIVIDUAL = register("ender_shard_no_individual", EnderShardNoIndividualItem::new);
	}

	// Start of user code block custom items
	// End of user code block custom items
	private static <I extends Item> DeferredItem<I> register(String name, Function<Item.Properties, ? extends I> supplier) {
		return REGISTRY.registerItem(name, supplier, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block) {
		return block(block, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block, Item.Properties properties) {
		return REGISTRY.registerItem(block.getId().getPath(), prop -> new BlockItem(block.get(), prop), properties);
	}

	@EventBusSubscriber(Dist.CLIENT)
	public static class ItemsClientSideHandler {
		@SubscribeEvent
		public static void registerItemModelProperties(RegisterRangeSelectItemModelPropertyEvent event) {
			event.register(ResourceLocation.parse("euru:ender_shard/count"), EnderShardItem.CountProperty.MAP_CODEC);
		}
	}
}