/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.wavedk.extrautilitiesreutilized.init;

import net.wavedk.extrautilitiesreutilized.block.*;
import net.wavedk.extrautilitiesreutilized.EuruMod;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredBlock;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.Block;

import java.util.function.Function;

public class EuruModBlocks {
	public static final DeferredRegister.Blocks REGISTRY = DeferredRegister.createBlocks(EuruMod.MODID);
	public static final DeferredBlock<Block> SOLAR_PANEL;
	public static final DeferredBlock<Block> LUNAR_PANEL;
	public static final DeferredBlock<Block> RESONATOR;
	public static final DeferredBlock<Block> CHUNK_LOADER;
	public static final DeferredBlock<Block> MACHINE_BLOCK;
	public static final DeferredBlock<Block> SURVIVAL_GENERATOR;
	public static final DeferredBlock<Block> CHUNK_LOADER_TESTER;
	public static final DeferredBlock<Block> GILDED_OBSIDIAN;
	public static final DeferredBlock<Block> ANGEL_BLOCK;
	static {
		SOLAR_PANEL = register("solar_panel", SolarPanelBlock::new);
		LUNAR_PANEL = register("lunar_panel", LunarPanelBlock::new);
		RESONATOR = register("resonator", ResonatorBlock::new);
		CHUNK_LOADER = register("chunk_loader", ChunkLoaderBlock::new);
		MACHINE_BLOCK = register("machine_block", MachineBlockBlock::new);
		SURVIVAL_GENERATOR = register("survival_generator", SurvivalGeneratorBlock::new);
		CHUNK_LOADER_TESTER = register("chunk_loader_tester", ChunkLoaderTesterBlock::new);
		GILDED_OBSIDIAN = register("gilded_obsidian", GildedObsidianBlock::new);
		ANGEL_BLOCK = register("angel_block", AngelBlockBlock::new);
	}

	// Start of user code block custom blocks
	// End of user code block custom blocks
	private static <B extends Block> DeferredBlock<B> register(String name, Function<BlockBehaviour.Properties, ? extends B> supplier) {
		return REGISTRY.registerBlock(name, supplier);
	}
}