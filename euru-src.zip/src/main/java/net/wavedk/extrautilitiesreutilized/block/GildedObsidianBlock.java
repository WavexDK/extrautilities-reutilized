package net.wavedk.extrautilitiesreutilized.block;

import net.minecraft.world.level.block.state.properties.NoteBlockInstrument;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.Block;

public class GildedObsidianBlock extends Block {
	public GildedObsidianBlock(BlockBehaviour.Properties properties) {
		super(properties.strength(30f, 700f).requiresCorrectToolForDrops().instrument(NoteBlockInstrument.BASEDRUM));
	}
}