package net.wavedk.extrautilitiesreutilized.procedures;

import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.core.BlockPos;

public class Arrow9Procedure {
	public static boolean execute(LevelAccessor world, double x, double y, double z) {
		double currentStep = 0;
		double stepNum = 0;
		double pStep = 0;
		pStep = 9;
		stepNum = Math.floor(getBlockNBTNumber(world, BlockPos.containing(x, y, z), "wait_time") / 22);
		if (getBlockNBTNumber(world, BlockPos.containing(x, y, z), "cProgress") >= stepNum * pStep && getBlockNBTNumber(world, BlockPos.containing(x, y, z), "cProgress") <= stepNum * (pStep + 1)) {
			currentStep = pStep;
		}
		if (!(getBlockNBTNumber(world, BlockPos.containing(x, y, z), "wait_time") == 0) && currentStep == pStep) {
			return true;
		}
		return false;
	}

	private static double getBlockNBTNumber(LevelAccessor world, BlockPos pos, String tag) {
		BlockEntity blockEntity = world.getBlockEntity(pos);
		if (blockEntity != null)
			return blockEntity.getPersistentData().getDoubleOr(tag, 0);
		return -1;
	}
}