package net.wavedk.extrautilitiesreutilized.procedures;

import org.checkerframework.checker.units.qual.A;

import org.apache.commons.lang3.function.FailableFunction;

import net.wavedk.extrautilitiesreutilized.network.EuruModVariables;
import net.wavedk.extrautilitiesreutilized.init.EuruModItems;
import net.wavedk.extrautilitiesreutilized.block.entity.SurvivalGeneratorBlockEntity;

import net.neoforged.neoforge.items.IItemHandlerModifiable;
import net.neoforged.neoforge.items.IItemHandler;
import net.neoforged.neoforge.energy.IEnergyStorage;
import net.neoforged.neoforge.common.extensions.ILevelExtension;
import net.neoforged.neoforge.capabilities.Capabilities;
import net.neoforged.fml.loading.FMLPaths;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.Vec2;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Entity;
import net.minecraft.tags.ItemTags;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.Direction;
import net.minecraft.core.BlockPos;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.CommandSource;

import java.util.function.Supplier;
import java.util.UUID;

import java.io.IOException;
import java.io.FileReader;
import java.io.File;
import java.io.BufferedReader;

public class SurvivalGeneratorOnTickUpdateProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z) {
		Entity player = null;
		File feConfig = new File("");
		com.google.gson.JsonArray fuelList = new com.google.gson.JsonArray();
		String currentItem = "";
		com.google.gson.JsonObject configOBJ = new com.google.gson.JsonObject();
		com.google.gson.JsonObject fuelPropertiesOBJ = new com.google.gson.JsonObject();
		com.google.gson.JsonObject itemOBJ = new com.google.gson.JsonObject();
		com.google.gson.JsonObject blockOBJ = new com.google.gson.JsonObject();
		double feGen = 0;
		double feSpeed = 0;
		double sentSouth = 0;
		double sentNorth = 0;
		double sentWest = 0;
		double sentEast = 0;
		double mult = 0;
		if (world.getServer() != null) {
			LevelAccessor _origWorld = world;
			for (ServerLevel worlditerator : world.getServer().getAllLevels()) {
				world = worlditerator;
				player = world instanceof ServerLevel _serverGetEntityUUID ? _serverGetEntityUUID.getEntity(tryOrDefault((getBlockNBTString(world, BlockPos.containing(x, y, z), "placedBy")), UUID::fromString, () -> new UUID(0, 0))) : null;
				if (player instanceof ServerPlayer || player instanceof Player) {
					break;
				}
			}
			world = _origWorld;
		}
		if (player instanceof ServerPlayer || player instanceof Player) {// redstoneMode
			if (getBlockNBTNumber(world, BlockPos.containing(x, y, z), "redstoneMode") == 0) {
				setBlockNBTLogic(world, x, y, z, "redstoneModeOn", true);
			} else if (getBlockNBTNumber(world, BlockPos.containing(x, y, z), "redstoneMode") == 1) {
				if (world instanceof Level _level11 && _level11.hasNeighborSignal(BlockPos.containing(x, y, z))) {
					setBlockNBTLogic(world, x, y, z, "redstoneModeOn", true);
				} else {
					setBlockNBTLogic(world, x, y, z, "redstoneModeOn", false);
				}
			} else if (getBlockNBTNumber(world, BlockPos.containing(x, y, z), "redstoneMode") == 2) {
				if (world instanceof Level _level15 && _level15.hasNeighborSignal(BlockPos.containing(x, y, z))) {
					setBlockNBTLogic(world, x, y, z, "redstoneModeOn", false);
				} else {
					setBlockNBTLogic(world, x, y, z, "redstoneModeOn", true);
				}
			} else if (getBlockNBTNumber(world, BlockPos.containing(x, y, z), "redstoneMode") == 3) {
				setBlockNBTLogic(world, x, y, z, "redstoneModeOn", false);
			} else {
				setBlockNBTLogic(world, x, y, z, "redstoneModeOn", true);
			} // multiplier
			mult = 1;
			if ((itemFromBlockInventory(world, BlockPos.containing(x, y, z), 1).copy()).getItem() == EuruModItems.SPEED_UPGRADE.get()) {
				mult = mult + itemFromBlockInventory(world, BlockPos.containing(x, y, z), 1).getCount() / 4d;
			} else if ((itemFromBlockInventory(world, BlockPos.containing(x, y, z), 1).copy()).getItem() == EuruModItems.MAGICAL_SPEED_UPGRADE.get()) {
				mult = mult + itemFromBlockInventory(world, BlockPos.containing(x, y, z), 1).getCount() / 2d;
			}
			if (player.getData(EuruModVariables.PLAYER_VARIABLES).playerGPChecking) {
				{
					EuruModVariables.PlayerVariables _vars = player.getData(EuruModVariables.PLAYER_VARIABLES);
					_vars.playerGP_Used_Update = player.getData(EuruModVariables.PLAYER_VARIABLES).playerGP_Used_Update + itemFromBlockInventory(world, BlockPos.containing(x, y, z), 1).getCount();
					_vars.markSyncDirty();
				}
			} // feGeneration
			if (getBlockNBTLogic(world, BlockPos.containing(x, y, z), "redstoneModeOn")) {
				feConfig = new File((FMLPaths.GAMEDIR.get().toString() + "/config/euru/"), File.separator + "euru_fe_config.json");
				if (!(player.getData(EuruModVariables.PLAYER_VARIABLES).playerGP_Total < player.getData(EuruModVariables.PLAYER_VARIABLES).playerGP_Used)) {
					setBlockNBTLogic(world, x, y, z, "tmGP", false);
				} else {
					setBlockNBTLogic(world, x, y, z, "tmGP", true);
				}
				if (getBlockNBTNumber(world, BlockPos.containing(x, y, z), "feGeneration") == 0 || getBlockNBTNumber(world, BlockPos.containing(x, y, z), "feSpeed") == 0 || getBlockNBTNumber(world, BlockPos.containing(x, y, z), "arrowTick") == 0
						|| (getBlockNBTString(world, BlockPos.containing(x, y, z), "currentItem")).equals("")) {
					if (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 0).getCount() != 0) {
						if (!getBlockNBTLogic(world, BlockPos.containing(x, y, z), "tmGP")) {
							{
								try {
									BufferedReader bufferedReader = new BufferedReader(new FileReader(feConfig));
									StringBuilder jsonstringbuilder = new StringBuilder();
									String line;
									while ((line = bufferedReader.readLine()) != null) {
										jsonstringbuilder.append(line);
									}
									bufferedReader.close();
									configOBJ = new com.google.gson.Gson().fromJson(jsonstringbuilder.toString(), com.google.gson.JsonObject.class);
									blockOBJ = configOBJ.get((BuiltInRegistries.BLOCK.getKey((world.getBlockState(BlockPos.containing(x, y, z))).getBlock()).toString())).getAsJsonObject();
									fuelList = blockOBJ.get("listFuel").getAsJsonArray();
									if (!(fuelList.size() == 0)) {
										for (double i_ = 0; i_ != fuelList.size(); i_ += 1) {
											if ((BuiltInRegistries.ITEM.getKey((itemFromBlockInventory(world, BlockPos.containing(x, y, z), 0).copy()).getItem()).toString()).equals(fuelList.get((int) i_).getAsString())) {
												fuelPropertiesOBJ = blockOBJ.get("fuelProperties").getAsJsonObject();
												itemOBJ = fuelPropertiesOBJ.get((BuiltInRegistries.ITEM.getKey((itemFromBlockInventory(world, BlockPos.containing(x, y, z), 0).copy()).getItem()).toString())).getAsJsonObject();
												setBlockNBTText(world, x, y, z, "currentItem", (BuiltInRegistries.ITEM.getKey((itemFromBlockInventory(world, BlockPos.containing(x, y, z), 0).copy()).getItem()).toString()));
												setBlockNBTNumber(world, x, y, z, "feSpeed", itemOBJ.get("feSpeed").getAsDouble());
												setBlockNBTNumber(world, x, y, z, "feGeneration", itemOBJ.get("feGenerated").getAsDouble());
												if (world instanceof ILevelExtension _ext && _ext.getCapability(Capabilities.ItemHandler.BLOCK, BlockPos.containing(x, y, z), null) instanceof IItemHandlerModifiable _itemHandlerModifiable) {
													ItemStack _setstack = (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 0).copy()).copy();
													_setstack.setCount(itemFromBlockInventory(world, BlockPos.containing(x, y, z), 0).getCount() - 1);
													_itemHandlerModifiable.setStackInSlot(0, _setstack);
												}
												break;
											} else if ((itemFromBlockInventory(world, BlockPos.containing(x, y, z), 0).copy())
													.is(ItemTags.create(ResourceLocation.parse((fuelList.get((int) i_).getAsString()).toLowerCase(java.util.Locale.ENGLISH))))) {// configHandling
												fuelPropertiesOBJ = blockOBJ.get("fuelProperties").getAsJsonObject();
												itemOBJ = fuelPropertiesOBJ.get(fuelList.get((int) i_).getAsString()).getAsJsonObject();
												setBlockNBTNumber(world, x, y, z, "arrowTick", (itemOBJ.get("feGenerated").getAsDouble() + 22));
												setBlockNBTNumber(world, x, y, z, "feGeneration", itemOBJ.get("feGenerated").getAsDouble());
												setBlockNBTNumber(world, x, y, z, "feSpeed", itemOBJ.get("feSpeed").getAsDouble());
												setBlockNBTText(world, x, y, z, "currentItem", fuelList.get((int) i_).getAsString());
												if (world instanceof ILevelExtension _ext && _ext.getCapability(Capabilities.ItemHandler.BLOCK, BlockPos.containing(x, y, z), null) instanceof IItemHandlerModifiable _itemHandlerModifiable) {
													ItemStack _setstack = (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 0).copy()).copy();
													_setstack.setCount(itemFromBlockInventory(world, BlockPos.containing(x, y, z), 0).getCount() - 1);
													_itemHandlerModifiable.setStackInSlot(0, _setstack);
												}
												break;
											}
										}
									} else {
										if (world instanceof ServerLevel _level)
											_level.getServer().getCommands().performPrefixedCommand(
													new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
													"say ERROR: Something has gone terribly wrong with Extra Utilities: Reutilized. Contact admins immediately. (E-101)");
									}
								} catch (IOException e) {
									e.printStackTrace();
								}
							}
						}
					}
				} else {
					if (getBlockNBTNumber(world, BlockPos.containing(x, y, z), "feGenerated") >= getBlockNBTNumber(world, BlockPos.containing(x, y, z), "feGeneration")) {
						setBlockNBTText(world, x, y, z, "currentItem", "");
						setBlockNBTNumber(world, x, y, z, "feGenerated", 0);
						setBlockNBTNumber(world, x, y, z, "feGeneration", 0);
						{
							try {
								BufferedReader bufferedReader = new BufferedReader(new FileReader(feConfig));
								StringBuilder jsonstringbuilder = new StringBuilder();
								String line;
								while ((line = bufferedReader.readLine()) != null) {
									jsonstringbuilder.append(line);
								}
								bufferedReader.close();
								configOBJ = new com.google.gson.Gson().fromJson(jsonstringbuilder.toString(), com.google.gson.JsonObject.class);
								blockOBJ = configOBJ.get((BuiltInRegistries.BLOCK.getKey((world.getBlockState(BlockPos.containing(x, y, z))).getBlock()).toString())).getAsJsonObject();
								fuelList = blockOBJ.get("listFuel").getAsJsonArray();
								if (!(fuelList.size() == 0)) {
									for (double i_ = 0; i_ != fuelList.size(); i_ += 1) {
										if ((BuiltInRegistries.ITEM.getKey((itemFromBlockInventory(world, BlockPos.containing(x, y, z), 0).copy()).getItem()).toString()).equals(fuelList.get((int) i_).getAsString())) {
											fuelPropertiesOBJ = blockOBJ.get("fuelProperties").getAsJsonObject();
											itemOBJ = fuelPropertiesOBJ.get((BuiltInRegistries.ITEM.getKey((itemFromBlockInventory(world, BlockPos.containing(x, y, z), 0).copy()).getItem()).toString())).getAsJsonObject();
											setBlockNBTText(world, x, y, z, "currentItem", (BuiltInRegistries.ITEM.getKey((itemFromBlockInventory(world, BlockPos.containing(x, y, z), 0).copy()).getItem()).toString()));
											setBlockNBTNumber(world, x, y, z, "feSpeed", itemOBJ.get("feSpeed").getAsDouble());
											setBlockNBTNumber(world, x, y, z, "feGeneration", itemOBJ.get("feGenerated").getAsDouble());
											setBlockNBTNumber(world, x, y, z, "arrowTick", (itemOBJ.get("feGenerated").getAsDouble() + 22));
											if (world instanceof ILevelExtension _ext && _ext.getCapability(Capabilities.ItemHandler.BLOCK, BlockPos.containing(x, y, z), null) instanceof IItemHandlerModifiable _itemHandlerModifiable) {
												ItemStack _setstack = (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 0).copy()).copy();
												_setstack.setCount(itemFromBlockInventory(world, BlockPos.containing(x, y, z), 0).getCount() - 1);
												_itemHandlerModifiable.setStackInSlot(0, _setstack);
											}
											break;
										} else if ((itemFromBlockInventory(world, BlockPos.containing(x, y, z), 0).copy()).is(ItemTags.create(ResourceLocation.parse((fuelList.get((int) i_).getAsString()).toLowerCase(java.util.Locale.ENGLISH))))) {// configHandling
											fuelPropertiesOBJ = blockOBJ.get("fuelProperties").getAsJsonObject();
											itemOBJ = fuelPropertiesOBJ.get(fuelList.get((int) i_).getAsString()).getAsJsonObject();
											setBlockNBTNumber(world, x, y, z, "arrowTick", (itemOBJ.get("feGenerated").getAsDouble() + 22));
											setBlockNBTNumber(world, x, y, z, "feGeneration", itemOBJ.get("feGenerated").getAsDouble());
											setBlockNBTNumber(world, x, y, z, "feSpeed", itemOBJ.get("feSpeed").getAsDouble());
											setBlockNBTText(world, x, y, z, "currentItem", fuelList.get((int) i_).getAsString());
											if (world instanceof ILevelExtension _ext && _ext.getCapability(Capabilities.ItemHandler.BLOCK, BlockPos.containing(x, y, z), null) instanceof IItemHandlerModifiable _itemHandlerModifiable) {
												ItemStack _setstack = (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 0).copy()).copy();
												_setstack.setCount(itemFromBlockInventory(world, BlockPos.containing(x, y, z), 0).getCount() - 1);
												_itemHandlerModifiable.setStackInSlot(0, _setstack);
											}
											break;
										}
									}
								} else {
									if (world instanceof ServerLevel _level)
										_level.getServer().getCommands().performPrefixedCommand(
												new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
												"say ERROR: Something has gone terribly wrong with Extra Utilities: Reutilized. Contact admins immediately. (E-101)");
								}
							} catch (IOException e) {
								e.printStackTrace();
							}
						}
						if (!(getBlockNBTString(world, BlockPos.containing(x, y, z), "currentItem")).equals("")) {
							if (!(player.getData(EuruModVariables.PLAYER_VARIABLES).playerGP_Total < player.getData(EuruModVariables.PLAYER_VARIABLES).playerGP_Used)) {
								setBooleanBlockState(world, x, y, z, "on", true);
								setBlockNBTLogic(world, x, y, z, "tmGP", false);
								if (getEnergyStored(world, BlockPos.containing(x, y, z), null) + getBlockNBTNumber(world, BlockPos.containing(x, y, z), "feSpeed") <= getMaxEnergyStored(world, BlockPos.containing(x, y, z), null)) {
									setBlockNBTNumber(world, x, y, z, "feGenerated", (getBlockNBTNumber(world, BlockPos.containing(x, y, z), "feGenerated") + getBlockNBTNumber(world, BlockPos.containing(x, y, z), "feSpeed") * mult));
									feSpeed = getBlockNBTNumber(world, BlockPos.containing(x, y, z), "feSpeed") * mult;
									if (world.getBlockEntity(new BlockPos((int) x, (int) y, (int) z)) instanceof SurvivalGeneratorBlockEntity be) {
										be.addEnergy((int) feSpeed);
									}
									if (getBlockNBTNumber(world, BlockPos.containing(x, y, z), "feGenerated") > getBlockNBTNumber(world, BlockPos.containing(x, y, z), "feGeneration")) {
										if (world instanceof ILevelExtension _ext) {
											IEnergyStorage _entityStorage = _ext.getCapability(Capabilities.EnergyStorage.BLOCK, BlockPos.containing(x, y, z), null);
											if (_entityStorage != null)
												_entityStorage.extractEnergy((int) (getBlockNBTNumber(world, BlockPos.containing(x, y, z), "feGenerated") - getBlockNBTNumber(world, BlockPos.containing(x, y, z), "feGeneration")), false);
										}
									}
									setBlockNBTNumber(world, x, y, z, "genCounter", 0);
								} else if (getEnergyStored(world, BlockPos.containing(x, y, z), null) < getMaxEnergyStored(world, BlockPos.containing(x, y, z), null)) {
									setBlockNBTNumber(world, x, y, z, "feGenerated", (getBlockNBTNumber(world, BlockPos.containing(x, y, z), "feGenerated") + getBlockNBTNumber(world, BlockPos.containing(x, y, z), "feSpeed") * mult));
									feSpeed = getMaxEnergyStored(world, BlockPos.containing(x, y, z), null) - getEnergyStored(world, BlockPos.containing(x, y, z), null);
									if (world.getBlockEntity(new BlockPos((int) x, (int) y, (int) z)) instanceof SurvivalGeneratorBlockEntity be) {
										be.addEnergy((int) feSpeed);
									}
									setBlockNBTNumber(world, x, y, z, "genCounter", 0);
								} else {
									if (getBlockNBTNumber(world, BlockPos.containing(x, y, z), "genCounter") > 19) {
										setBlockNBTNumber(world, x, y, z, "feGenerated", (getBlockNBTNumber(world, BlockPos.containing(x, y, z), "feGenerated") + getBlockNBTNumber(world, BlockPos.containing(x, y, z), "feSpeed")));
										setBlockNBTNumber(world, x, y, z, "genCounter", 0);
									} else {
										setBlockNBTNumber(world, x, y, z, "genCounter", (getBlockNBTNumber(world, BlockPos.containing(x, y, z), "genCounter") + 1));
									}
								}
							} else {
								setBooleanBlockState(world, x, y, z, "on", false);
								setBlockNBTLogic(world, x, y, z, "tmGP", true);
							}
						} else {
							setBooleanBlockState(world, x, y, z, "on", false);
						}
					} else {
						if (!(player.getData(EuruModVariables.PLAYER_VARIABLES).playerGP_Total < player.getData(EuruModVariables.PLAYER_VARIABLES).playerGP_Used)) {
							setBooleanBlockState(world, x, y, z, "on", true);
							setBlockNBTLogic(world, x, y, z, "tmGP", false);
							if (getEnergyStored(world, BlockPos.containing(x, y, z), null) + getBlockNBTNumber(world, BlockPos.containing(x, y, z), "feSpeed") <= getMaxEnergyStored(world, BlockPos.containing(x, y, z), null)) {
								setBlockNBTNumber(world, x, y, z, "feGenerated", (getBlockNBTNumber(world, BlockPos.containing(x, y, z), "feGenerated") + getBlockNBTNumber(world, BlockPos.containing(x, y, z), "feSpeed") * mult));
								feSpeed = getBlockNBTNumber(world, BlockPos.containing(x, y, z), "feSpeed") * mult;
								if (world.getBlockEntity(new BlockPos((int) x, (int) y, (int) z)) instanceof SurvivalGeneratorBlockEntity be) {
									be.addEnergy((int) feSpeed);
								}
								if (getBlockNBTNumber(world, BlockPos.containing(x, y, z), "feGenerated") > getBlockNBTNumber(world, BlockPos.containing(x, y, z), "feGeneration")) {
									if (world instanceof ILevelExtension _ext) {
										IEnergyStorage _entityStorage = _ext.getCapability(Capabilities.EnergyStorage.BLOCK, BlockPos.containing(x, y, z), null);
										if (_entityStorage != null)
											_entityStorage.extractEnergy((int) (getBlockNBTNumber(world, BlockPos.containing(x, y, z), "feGenerated") - getBlockNBTNumber(world, BlockPos.containing(x, y, z), "feGeneration")), false);
									}
								}
								setBlockNBTNumber(world, x, y, z, "genCounter", 0);
							} else if (getEnergyStored(world, BlockPos.containing(x, y, z), null) < getMaxEnergyStored(world, BlockPos.containing(x, y, z), null)) {
								setBlockNBTNumber(world, x, y, z, "feGenerated", (getBlockNBTNumber(world, BlockPos.containing(x, y, z), "feGenerated") + getBlockNBTNumber(world, BlockPos.containing(x, y, z), "feSpeed") * mult));
								feSpeed = getMaxEnergyStored(world, BlockPos.containing(x, y, z), null) - getEnergyStored(world, BlockPos.containing(x, y, z), null);
								if (world.getBlockEntity(new BlockPos((int) x, (int) y, (int) z)) instanceof SurvivalGeneratorBlockEntity be) {
									be.addEnergy((int) feSpeed);
								}
								setBlockNBTNumber(world, x, y, z, "genCounter", 0);
							} else {
								if (getBlockNBTNumber(world, BlockPos.containing(x, y, z), "genCounter") > 19) {
									setBlockNBTNumber(world, x, y, z, "feGenerated", (getBlockNBTNumber(world, BlockPos.containing(x, y, z), "feGenerated") + getBlockNBTNumber(world, BlockPos.containing(x, y, z), "feSpeed")));
									setBlockNBTNumber(world, x, y, z, "genCounter", 0);
								} else {
									setBlockNBTNumber(world, x, y, z, "genCounter", (getBlockNBTNumber(world, BlockPos.containing(x, y, z), "genCounter") + 1));
								}
							}
						} else {
							setBooleanBlockState(world, x, y, z, "on", false);
							setBlockNBTLogic(world, x, y, z, "tmGP", true);
						}
					}
				}
			} // energyHandling
			//
			sentSouth = receiveEnergySimulate(world, BlockPos.containing(x, y, z + 1), 5, Direction.NORTH);
			sentNorth = receiveEnergySimulate(world, BlockPos.containing(x, y, z - 1), 5, Direction.SOUTH);
			sentEast = receiveEnergySimulate(world, BlockPos.containing(x + 1, y, z), 5, Direction.WEST);
			sentWest = receiveEnergySimulate(world, BlockPos.containing(x - 1, y, z), 5, Direction.EAST);// south
			if (sentSouth > 0) {
				if (getEnergyStored(world, BlockPos.containing(x, y, z), null) >= sentSouth) {
					if (world instanceof ILevelExtension _ext) {
						IEnergyStorage _entityStorage = _ext.getCapability(Capabilities.EnergyStorage.BLOCK, BlockPos.containing(x, y, z), null);
						if (_entityStorage != null)
							_entityStorage.extractEnergy((int) sentSouth, false);
					}
					if (world instanceof ILevelExtension _ext) {
						IEnergyStorage _entityStorage = _ext.getCapability(Capabilities.EnergyStorage.BLOCK, BlockPos.containing(x, y, z + 1), Direction.NORTH);
						if (_entityStorage != null)
							_entityStorage.receiveEnergy((int) sentSouth, false);
					}
				}
			} // north
			if (sentNorth > 0) {
				if (getEnergyStored(world, BlockPos.containing(x, y, z), null) >= sentNorth) {
					if (world instanceof ILevelExtension _ext) {
						IEnergyStorage _entityStorage = _ext.getCapability(Capabilities.EnergyStorage.BLOCK, BlockPos.containing(x, y, z), null);
						if (_entityStorage != null)
							_entityStorage.extractEnergy((int) sentNorth, false);
					}
					if (world instanceof ILevelExtension _ext) {
						IEnergyStorage _entityStorage = _ext.getCapability(Capabilities.EnergyStorage.BLOCK, BlockPos.containing(x, y, z - 1), Direction.SOUTH);
						if (_entityStorage != null)
							_entityStorage.receiveEnergy((int) sentNorth, false);
					}
				}
			} // east
			if (sentEast > 0) {
				if (getEnergyStored(world, BlockPos.containing(x, y, z), null) >= sentEast) {
					if (world instanceof ILevelExtension _ext) {
						IEnergyStorage _entityStorage = _ext.getCapability(Capabilities.EnergyStorage.BLOCK, BlockPos.containing(x, y, z), null);
						if (_entityStorage != null)
							_entityStorage.extractEnergy((int) sentEast, false);
					}
					if (world instanceof ILevelExtension _ext) {
						IEnergyStorage _entityStorage = _ext.getCapability(Capabilities.EnergyStorage.BLOCK, BlockPos.containing(x + 1, y, z), Direction.WEST);
						if (_entityStorage != null)
							_entityStorage.receiveEnergy((int) sentEast, false);
					}
				}
			} // west
			if (sentWest > 0) {
				if (getEnergyStored(world, BlockPos.containing(x, y, z), null) >= sentWest) {
					if (world instanceof ILevelExtension _ext) {
						IEnergyStorage _entityStorage = _ext.getCapability(Capabilities.EnergyStorage.BLOCK, BlockPos.containing(x, y, z), null);
						if (_entityStorage != null)
							_entityStorage.extractEnergy((int) sentWest, false);
					}
					if (world instanceof ILevelExtension _ext) {
						IEnergyStorage _entityStorage = _ext.getCapability(Capabilities.EnergyStorage.BLOCK, BlockPos.containing(x - 1, y, z), Direction.EAST);
						if (_entityStorage != null)
							_entityStorage.receiveEnergy((int) sentWest, false);
					}
				}
			} // arrowHandling
			setBlockNBTNumber(world, x, y, z, "wait_time", (getBlockNBTNumber(world, BlockPos.containing(x, y, z), "feGeneration")));
			setBlockNBTNumber(world, x, y, z, "cProgress", (getBlockNBTNumber(world, BlockPos.containing(x, y, z), "feGenerated")));
		}
	}

	private static String getBlockNBTString(LevelAccessor world, BlockPos pos, String tag) {
		BlockEntity blockEntity = world.getBlockEntity(pos);
		if (blockEntity != null)
			return blockEntity.getPersistentData().getStringOr(tag, "");
		return "";
	}

	private static <A, B> A tryOrDefault(B funcArg, FailableFunction<B, A, Exception> func, Supplier<A> fallback) {
		try {
			return func.apply(funcArg);
		} catch (Exception e) {
			return fallback.get();
		}
	}

	private static double getBlockNBTNumber(LevelAccessor world, BlockPos pos, String tag) {
		BlockEntity blockEntity = world.getBlockEntity(pos);
		if (blockEntity != null)
			return blockEntity.getPersistentData().getDoubleOr(tag, 0);
		return -1;
	}

	private static void setBlockNBTLogic(LevelAccessor world, double x, double y, double z, String tag, boolean value) {
		if (!world.isClientSide()) {
			BlockPos pos = BlockPos.containing(x, y, z);
			BlockEntity blockEntity = world.getBlockEntity(pos);
			BlockState blockState = world.getBlockState(pos);
			if (blockEntity != null) {
				blockEntity.getPersistentData().putBoolean(tag, value);
			}
			if (world instanceof Level level) {
				level.sendBlockUpdated(pos, blockState, blockState, 3);
			}
		}
	}

	private static ItemStack itemFromBlockInventory(LevelAccessor world, BlockPos pos, int slot) {
		if (world instanceof ILevelExtension ext) {
			IItemHandler itemHandler = ext.getCapability(Capabilities.ItemHandler.BLOCK, pos, null);
			if (itemHandler != null)
				return itemHandler.getStackInSlot(slot);
		}
		return ItemStack.EMPTY;
	}

	private static boolean getBlockNBTLogic(LevelAccessor world, BlockPos pos, String tag) {
		BlockEntity blockEntity = world.getBlockEntity(pos);
		if (blockEntity != null)
			return blockEntity.getPersistentData().getBooleanOr(tag, false);
		return false;
	}

	private static void setBlockNBTText(LevelAccessor world, double x, double y, double z, String tag, String value) {
		if (!world.isClientSide()) {
			BlockPos pos = BlockPos.containing(x, y, z);
			BlockEntity blockEntity = world.getBlockEntity(pos);
			BlockState blockState = world.getBlockState(pos);
			if (blockEntity != null) {
				blockEntity.getPersistentData().putString(tag, value);
			}
			if (world instanceof Level level) {
				level.sendBlockUpdated(pos, blockState, blockState, 3);
			}
		}
	}

	private static void setBlockNBTNumber(LevelAccessor world, double x, double y, double z, String tag, double value) {
		if (!world.isClientSide()) {
			BlockPos pos = BlockPos.containing(x, y, z);
			BlockEntity blockEntity = world.getBlockEntity(pos);
			BlockState blockState = world.getBlockState(pos);
			if (blockEntity != null) {
				blockEntity.getPersistentData().putDouble(tag, value);
			}
			if (world instanceof Level level) {
				level.sendBlockUpdated(pos, blockState, blockState, 3);
			}
		}
	}

	private static void setBooleanBlockState(LevelAccessor world, double x, double y, double z, String property, boolean value) {
		BlockPos pos = BlockPos.containing(x, y, z);
		BlockState state = world.getBlockState(pos);
		if (state.getBlock().getStateDefinition().getProperty(property) instanceof BooleanProperty booleanProperty) {
			world.setBlock(pos, state.setValue(booleanProperty, value), 3);
		}
	}

	public static int getEnergyStored(LevelAccessor level, BlockPos pos, Direction direction) {
		if (level instanceof ILevelExtension levelExtension) {
			IEnergyStorage energyStorage = levelExtension.getCapability(Capabilities.EnergyStorage.BLOCK, pos, direction);
			if (energyStorage != null)
				return energyStorage.getEnergyStored();
		}
		return 0;
	}

	public static int getMaxEnergyStored(LevelAccessor level, BlockPos pos, Direction direction) {
		if (level instanceof ILevelExtension levelExtension) {
			IEnergyStorage energyStorage = levelExtension.getCapability(Capabilities.EnergyStorage.BLOCK, pos, direction);
			if (energyStorage != null)
				return energyStorage.getMaxEnergyStored();
		}
		return 0;
	}

	private static int receiveEnergySimulate(LevelAccessor level, BlockPos pos, int amount, Direction direction) {
		if (level instanceof ILevelExtension levelExtension) {
			IEnergyStorage energyStorage = levelExtension.getCapability(Capabilities.EnergyStorage.BLOCK, pos, direction);
			if (energyStorage != null)
				return energyStorage.receiveEnergy(amount, true);
		}
		return 0;
	}
}