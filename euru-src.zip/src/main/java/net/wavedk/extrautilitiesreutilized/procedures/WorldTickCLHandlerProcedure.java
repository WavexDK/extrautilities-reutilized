package net.wavedk.extrautilitiesreutilized.procedures;

import org.checkerframework.checker.units.qual.A;

import org.apache.commons.lang3.function.FailableFunction;

import net.wavedk.extrautilitiesreutilized.network.EuruModVariables;

import net.neoforged.neoforge.event.tick.LevelTickEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.bus.api.Event;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.Vec2;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Entity;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.network.chat.Component;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.CommandSource;

import javax.annotation.Nullable;

import java.util.function.Supplier;
import java.util.UUID;

@EventBusSubscriber
public class WorldTickCLHandlerProcedure {
	@SubscribeEvent
	public static void onWorldTick(LevelTickEvent.Post event) {
		execute(event, event.getLevel());
	}

	public static void execute(LevelAccessor world) {
		execute(null, world);
	}

	private static void execute(@Nullable Event event, LevelAccessor world) {
		Entity player = null;
		String uuidOfPlayer = "";
		String worldDimID = "";
		if (EuruModVariables.WorldVariables.get(world).chunkloaderCounter > 10) {
			EuruModVariables.WorldVariables.get(world).chunkloaderCounter = 0;
			EuruModVariables.WorldVariables.get(world).markSyncDirty();
			if (!EuruModVariables.WorldVariables.get(world).chunksloaded.isEmpty()) {
				for (Object arraylistiterator : EuruModVariables.WorldVariables.get(world).chunksloaded) {
					uuidOfPlayer = ((arraylistiterator instanceof String _str2 ? _str2 : "").substring(0, (arraylistiterator instanceof String _str4 ? _str4 : "").indexOf(".", 0))).replace(".", "");
					if (world.getServer() != null) {
						LevelAccessor _origWorld = world;
						for (ServerLevel worlditerator : world.getServer().getAllLevels()) {
							world = worlditerator;
							player = world instanceof ServerLevel _serverGetEntityUUID ? _serverGetEntityUUID.getEntity(tryOrDefault(uuidOfPlayer, UUID::fromString, () -> new UUID(0, 0))) : null;
							if (player instanceof ServerPlayer || player instanceof Player) {
								break;
							}
						}
						world = _origWorld;
					}
					if (player instanceof ServerPlayer || player instanceof Player) {
						if (!(player.getData(EuruModVariables.PLAYER_VARIABLES).playerGPChecking && player.getData(EuruModVariables.PLAYER_VARIABLES).playerGP_Total < player.getData(EuruModVariables.PLAYER_VARIABLES).playerGP_Used)) {
							if (world.getServer() != null) {
								LevelAccessor _origWorld = world;
								for (ServerLevel worlditerator : world.getServer().getAllLevels()) {
									world = worlditerator;
									worldDimID = (((arraylistiterator instanceof String _str13 ? _str13 : "").substring((arraylistiterator instanceof String _str15 ? _str15 : "").indexOf(".", 0),
											(arraylistiterator instanceof String _str17 ? _str17 : "").indexOf(",", 0))).replace(".", "")).replace(",", "");
									if ((worldDimID).equals("" + (world instanceof Level _lvl ? _lvl.dimension() : (world instanceof WorldGenLevel _wgl ? _wgl.getLevel().dimension() : Level.OVERWORLD)))) {
										if (world instanceof ServerLevel _level)
											_level.getServer().getCommands().performPrefixedCommand(
													new CommandSourceStack(CommandSource.NULL, new Vec3(0, 0, 0), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
													(("forceload add " + ((arraylistiterator instanceof String _str20 ? _str20 : "").substring((arraylistiterator instanceof String _str22 ? _str22 : "").indexOf(",", 0)))).replace(",", "")));
										break;
									}
								}
								world = _origWorld;
							}
						} else {
							if (world.getServer() != null) {
								LevelAccessor _origWorld = world;
								for (ServerLevel worlditerator : world.getServer().getAllLevels()) {
									world = worlditerator;
									worldDimID = (((arraylistiterator instanceof String _str26 ? _str26 : "").substring((arraylistiterator instanceof String _str28 ? _str28 : "").indexOf(".", 0),
											(arraylistiterator instanceof String _str30 ? _str30 : "").indexOf(",", 0))).replace(".", "")).replace(",", "");
									if ((worldDimID).equals("" + (world instanceof Level _lvl ? _lvl.dimension() : (world instanceof WorldGenLevel _wgl ? _wgl.getLevel().dimension() : Level.OVERWORLD)))) {
										if (world instanceof ServerLevel _level)
											_level.getServer().getCommands().performPrefixedCommand(
													new CommandSourceStack(CommandSource.NULL, new Vec3(0, 0, 0), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
													(("forceload remove" + ((arraylistiterator instanceof String _str33 ? _str33 : "").substring((arraylistiterator instanceof String _str35 ? _str35 : "").indexOf(",", 0)))).replace(",", "")));
										break;
									}
								}
								world = _origWorld;
							}
							EuruModVariables.WorldVariables.get(world).chunksloaded.remove((int) EuruModVariables.WorldVariables.get(world).chunksloaded.indexOf(arraylistiterator));
						}
					}
				}
			}
		} else {
			EuruModVariables.WorldVariables.get(world).chunkloaderCounter = EuruModVariables.WorldVariables.get(world).chunkloaderCounter + 1;
			EuruModVariables.WorldVariables.get(world).markSyncDirty();
		}
	}

	private static <A, B> A tryOrDefault(B funcArg, FailableFunction<B, A, Exception> func, Supplier<A> fallback) {
		try {
			return func.apply(funcArg);
		} catch (Exception e) {
			return fallback.get();
		}
	}
}