package net.wavedk.extrautilitiesreutilized.procedures;

import net.wavedk.extrautilitiesreutilized.network.EuruModVariables;
import net.wavedk.extrautilitiesreutilized.init.EuruModItems;
import net.wavedk.extrautilitiesreutilized.init.EuruModBlocks;

import net.neoforged.fml.loading.FMLPaths;
import net.neoforged.fml.event.lifecycle.FMLCommonSetupEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.bus.api.Event;

import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.item.Items;
import net.minecraft.core.registries.BuiltInRegistries;

import javax.annotation.Nullable;

import java.io.IOException;
import java.io.FileWriter;
import java.io.FileReader;
import java.io.File;
import java.io.BufferedReader;

@EventBusSubscriber
public class EURURecipesProcedure {
	@SubscribeEvent
	public static void init(FMLCommonSetupEvent event) {
		execute();
	}

	public static void execute() {
		execute(null);
	}

	private static void execute(@Nullable Event event) {
		File configFile = new File("");
		File file = new File("");
		double cVer = 0;
		com.google.gson.JsonObject configJsonObject = new com.google.gson.JsonObject();
		com.google.gson.JsonObject configSubJsonObjest = new com.google.gson.JsonObject();
		com.google.gson.JsonObject solarpanelObject = new com.google.gson.JsonObject();
		com.google.gson.JsonObject lunarobj = new com.google.gson.JsonObject();
		com.google.gson.JsonObject lunarlapisOBJ = new com.google.gson.JsonObject();
		configFile = new File((FMLPaths.GAMEDIR.get().toString() + "/config/euru/"), File.separator + "euru_recipes.json");
		cVer = EuruModVariables.cVer;
		if (!configFile.exists()) {
			try {
				configFile.getParentFile().mkdirs();
				configFile.createNewFile();
			} catch (IOException exception) {
				exception.printStackTrace();
			}
			lunarobj.addProperty("output", (BuiltInRegistries.ITEM.getKey(EuruModItems.UPGRADE_BASE.get()).toString()));
			lunarobj.addProperty("gp_required", 8);
			lunarobj.addProperty("wait_time", 200);
			configSubJsonObjest.add((BuiltInRegistries.ITEM.getKey(Blocks.LIGHT_WEIGHTED_PRESSURE_PLATE.asItem()).toString()), lunarobj);
			lunarlapisOBJ.addProperty("output", (BuiltInRegistries.ITEM.getKey(EuruModItems.LUNAR_REACTIVE_DUST.get()).toString()));
			lunarlapisOBJ.addProperty("gp_required", 16);
			lunarlapisOBJ.addProperty("wait_time", 400);
			configSubJsonObjest.add((BuiltInRegistries.ITEM.getKey(Items.LAPIS_LAZULI).toString()), lunarlapisOBJ);
			configJsonObject.add((BuiltInRegistries.ITEM.getKey(EuruModBlocks.RESONATOR.get().asItem()).toString()), configSubJsonObjest);
			configJsonObject.addProperty("config_version", cVer);
			{
				com.google.gson.Gson mainGSONBuilderVariable = new com.google.gson.GsonBuilder().setPrettyPrinting().create();
				try {
					FileWriter fileWriter = new FileWriter(configFile);
					fileWriter.write(mainGSONBuilderVariable.toJson(configJsonObject));
					fileWriter.close();
				} catch (IOException exception) {
					exception.printStackTrace();
				}
			}
		} else {
			{
				try {
					BufferedReader bufferedReader = new BufferedReader(new FileReader(configFile));
					StringBuilder jsonstringbuilder = new StringBuilder();
					String line;
					while ((line = bufferedReader.readLine()) != null) {
						jsonstringbuilder.append(line);
					}
					bufferedReader.close();
					configJsonObject = new com.google.gson.Gson().fromJson(jsonstringbuilder.toString(), com.google.gson.JsonObject.class);
					if (configJsonObject.get("config_version").isJsonPrimitive() ? configJsonObject.get("config_version").getAsJsonPrimitive().isNumber() : false) {
						if (configJsonObject.get("config_version").getAsDouble() != cVer) {
							configFile.delete();
							EURURecipesProcedure.execute();
						}
					} else {
						configFile.delete();
						EURURecipesProcedure.execute();
					}
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}
}