package net.wavedk.extrautilitiesreutilized.procedures;

import net.wavedk.extrautilitiesreutilized.network.EuruModVariables;
import net.wavedk.extrautilitiesreutilized.init.EuruModBlocks;

import net.neoforged.fml.loading.FMLPaths;
import net.neoforged.fml.event.lifecycle.FMLCommonSetupEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.bus.api.Event;

import net.minecraft.core.registries.BuiltInRegistries;

import javax.annotation.Nullable;

import java.io.IOException;
import java.io.FileWriter;
import java.io.FileReader;
import java.io.File;
import java.io.BufferedReader;

@EventBusSubscriber
public class EURUConfigManagerProcedure {
	@SubscribeEvent
	public static void init(FMLCommonSetupEvent event) {
		execute();
	}

	public static void execute() {
		execute(null);
	}

	private static void execute(@Nullable Event event) {
		File configFile = new File("");
		File file = new File("");
		double cVer = 0;
		com.google.gson.JsonObject configJsonObject = new com.google.gson.JsonObject();
		com.google.gson.JsonObject configSubJsonObjest = new com.google.gson.JsonObject();
		com.google.gson.JsonObject solarpanelObject = new com.google.gson.JsonObject();
		com.google.gson.JsonObject lunarobj = new com.google.gson.JsonObject();
		com.google.gson.JsonObject clOBJ = new com.google.gson.JsonObject();
		com.google.gson.JsonObject clt = new com.google.gson.JsonObject();
		configFile = new File((FMLPaths.GAMEDIR.get().toString() + "/config/euru/"), File.separator + "euru_config.json");
		cVer = EuruModVariables.cVer;
		if (!configFile.exists()) {
			try {
				configFile.getParentFile().mkdirs();
				configFile.createNewFile();
			} catch (IOException exception) {
				exception.printStackTrace();
			}
			solarpanelObject.addProperty("gp_generated", 1);
			solarpanelObject.addProperty("needs_sky", true);
			solarpanelObject.addProperty("needs_day", true);
			solarpanelObject.addProperty("needs_night", false);
			configJsonObject.add((BuiltInRegistries.ITEM.getKey(EuruModBlocks.SOLAR_PANEL.get().asItem()).toString()), solarpanelObject);
			lunarobj.addProperty("gp_generated", 0.7);
			lunarobj.addProperty("needs_sky", true);
			lunarobj.addProperty("needs_day", false);
			lunarobj.addProperty("needs_night", true);
			configJsonObject.add((BuiltInRegistries.ITEM.getKey(EuruModBlocks.LUNAR_PANEL.get().asItem()).toString()), lunarobj);
			clOBJ.addProperty("gp_needed", 8);
			configJsonObject.add((BuiltInRegistries.ITEM.getKey(EuruModBlocks.CHUNK_LOADER.get().asItem()).toString()), clOBJ);
			clt.addProperty("enabled", true);
			configJsonObject.add((BuiltInRegistries.ITEM.getKey(EuruModBlocks.CHUNK_LOADER_TESTER.get().asItem()).toString()), clt);
			configJsonObject.addProperty("config_version", cVer);
			{
				com.google.gson.Gson mainGSONBuilderVariable = new com.google.gson.GsonBuilder().setPrettyPrinting().create();
				try {
					FileWriter fileWriter = new FileWriter(configFile);
					fileWriter.write(mainGSONBuilderVariable.toJson(configJsonObject));
					fileWriter.close();
				} catch (IOException exception) {
					exception.printStackTrace();
				}
			}
		} else {
			{
				try {
					BufferedReader bufferedReader = new BufferedReader(new FileReader(configFile));
					StringBuilder jsonstringbuilder = new StringBuilder();
					String line;
					while ((line = bufferedReader.readLine()) != null) {
						jsonstringbuilder.append(line);
					}
					bufferedReader.close();
					configJsonObject = new com.google.gson.Gson().fromJson(jsonstringbuilder.toString(), com.google.gson.JsonObject.class);
					if (configJsonObject.get("config_version").isJsonPrimitive() ? configJsonObject.get("config_version").getAsJsonPrimitive().isNumber() : false) {
						if (configJsonObject.get("config_version").getAsDouble() != cVer) {
							configFile.delete();
							EURUConfigManagerProcedure.execute();
						}
					} else {
						configFile.delete();
						EURUConfigManagerProcedure.execute();
					}
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}
}