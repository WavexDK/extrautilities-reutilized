package net.wavedk.extrautilitiesreutilized.procedures;

import net.wavedk.extrautilitiesreutilized.network.EuruModVariables;

import net.neoforged.fml.loading.FMLPaths;
import net.neoforged.fml.event.lifecycle.FMLCommonSetupEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.bus.api.Event;

import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.item.Items;
import net.minecraft.core.registries.BuiltInRegistries;

import javax.annotation.Nullable;

import java.io.*;

@EventBusSubscriber
public class EURURecipeHandlerProcedure {
	@SubscribeEvent
	public static void init(FMLCommonSetupEvent event) {
		execute();
	}

	public static void execute() {
		execute(null);
	}

	private static void execute(@Nullable Event event) {
		File recipeList = new File("");
		double cVer = 0;
		String cver = "";
		boolean foundConfig = false;
		cVer = EuruModVariables.cVer;
		recipeList = new File((FMLPaths.GAMEDIR.get().toString() + "/config/euru/recipelists/"), File.separator + "resonator.txt");
		if (!recipeList.exists()) {
			try {
				recipeList.getParentFile().mkdirs();
				recipeList.createNewFile();
			} catch (IOException exception) {
				exception.printStackTrace();
			}
			try {
				FileWriter recipeListwriter = new FileWriter(recipeList, true);
				BufferedWriter recipeListbw = new BufferedWriter(recipeListwriter);
				{
					recipeListbw.write(("DO.NOT.DELETE.OR.CHANGE-config.version=" + cVer));
					recipeListbw.newLine();
				}
				{
					recipeListbw.write((BuiltInRegistries.ITEM.getKey(Blocks.LIGHT_WEIGHTED_PRESSURE_PLATE.asItem()).toString()));
					recipeListbw.newLine();
				}
				{
					recipeListbw.write((BuiltInRegistries.ITEM.getKey(Items.LAPIS_LAZULI).toString()));
					recipeListbw.newLine();
				}
				recipeListbw.close();
				recipeListwriter.close();
			} catch (IOException exception) {
				exception.printStackTrace();
			}
		} else {
			try {
				BufferedReader recipeListReader = new BufferedReader(new FileReader(recipeList));
				String stringiterator = "";
				while ((stringiterator = recipeListReader.readLine()) != null) {
					if (stringiterator.contains("DO.NOT.DELETE.OR.CHANGE-config.version=")) {
						if (!(stringiterator.replace("DO.NOT.DELETE.OR.CHANGE-config.version=", "")).equals("" + cVer)) {
							recipeList.delete();
							EURURecipesProcedure.execute();
						}
						foundConfig = true;
					}
				}
				recipeListReader.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
			if (!foundConfig) {
				recipeList.delete();
				EURURecipesProcedure.execute();
			}
		}
	}
}