package net.wavedk.extrautilitiesreutilized.procedures;

import net.wavedk.extrautilitiesreutilized.network.EuruModVariables;
import net.wavedk.extrautilitiesreutilized.init.EuruModBlocks;

import net.neoforged.fml.loading.FMLPaths;
import net.neoforged.fml.event.lifecycle.FMLCommonSetupEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.bus.api.Event;

import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.item.Items;
import net.minecraft.core.registries.BuiltInRegistries;

import javax.annotation.Nullable;

import java.io.IOException;
import java.io.FileWriter;
import java.io.FileReader;
import java.io.File;
import java.io.BufferedReader;

@EventBusSubscriber
public class EURUGeneratorsManagerProcedure {
	@SubscribeEvent
	public static void init(FMLCommonSetupEvent event) {
		execute();
	}

	public static void execute() {
		execute(null);
	}

	private static void execute(@Nullable Event event) {
		File configFile = new File("");
		File file = new File("");
		double cVer = 0;
		String cItem = "";
		com.google.gson.JsonArray sArray = new com.google.gson.JsonArray();
		com.google.gson.JsonArray cItemArray = new com.google.gson.JsonArray();
		com.google.gson.JsonObject configSubJsonObjest = new com.google.gson.JsonObject();
		com.google.gson.JsonObject configJsonObject = new com.google.gson.JsonObject();
		com.google.gson.JsonObject fuelPropertiesOBJ = new com.google.gson.JsonObject();
		com.google.gson.JsonObject coalOBJ = new com.google.gson.JsonObject();
		com.google.gson.JsonObject saplingsobj = new com.google.gson.JsonObject();
		com.google.gson.JsonObject logsobj = new com.google.gson.JsonObject();
		com.google.gson.JsonObject planksobj = new com.google.gson.JsonObject();
		com.google.gson.JsonObject stickobj = new com.google.gson.JsonObject();
		com.google.gson.JsonObject wool = new com.google.gson.JsonObject();
		com.google.gson.JsonObject carpet = new com.google.gson.JsonObject();
		com.google.gson.JsonObject day = new com.google.gson.JsonObject();
		com.google.gson.JsonObject wsword = new com.google.gson.JsonObject();
		com.google.gson.JsonObject waxe = new com.google.gson.JsonObject();
		com.google.gson.JsonObject wpick = new com.google.gson.JsonObject();
		com.google.gson.JsonObject wsho = new com.google.gson.JsonObject();
		com.google.gson.JsonObject whoe = new com.google.gson.JsonObject();
		com.google.gson.JsonObject shield = new com.google.gson.JsonObject();
		com.google.gson.JsonObject stickcarrot = new com.google.gson.JsonObject();
		com.google.gson.JsonObject warpstick = new com.google.gson.JsonObject();
		com.google.gson.JsonObject bookshelf = new com.google.gson.JsonObject();
		com.google.gson.JsonObject cbookshelf = new com.google.gson.JsonObject();
		com.google.gson.JsonObject button = new com.google.gson.JsonObject();
		com.google.gson.JsonObject wooden_doors = new com.google.gson.JsonObject();
		com.google.gson.JsonObject wooden_fences = new com.google.gson.JsonObject();
		com.google.gson.JsonObject wooden_pressure_plates = new com.google.gson.JsonObject();
		com.google.gson.JsonObject wooden_slabs = new com.google.gson.JsonObject();
		com.google.gson.JsonObject wooden_stairs = new com.google.gson.JsonObject();
		com.google.gson.JsonObject wooden_trapdoors = new com.google.gson.JsonObject();
		com.google.gson.JsonObject coalblock = new com.google.gson.JsonObject();
		com.google.gson.JsonObject craft = new com.google.gson.JsonObject();
		com.google.gson.JsonObject chest = new com.google.gson.JsonObject();
		com.google.gson.JsonObject tchest = new com.google.gson.JsonObject();
		com.google.gson.JsonObject ladder = new com.google.gson.JsonObject();
		com.google.gson.JsonObject juke = new com.google.gson.JsonObject();
		com.google.gson.JsonObject bowl = new com.google.gson.JsonObject();
		com.google.gson.JsonObject signs = new com.google.gson.JsonObject();
		com.google.gson.JsonObject bow = new com.google.gson.JsonObject();
		com.google.gson.JsonObject cbow = new com.google.gson.JsonObject();
		com.google.gson.JsonObject boats = new com.google.gson.JsonObject();
		com.google.gson.JsonObject beds = new com.google.gson.JsonObject();
		com.google.gson.JsonObject beehive = new com.google.gson.JsonObject();
		com.google.gson.JsonObject torch = new com.google.gson.JsonObject();
		com.google.gson.JsonObject torchred = new com.google.gson.JsonObject();
		com.google.gson.JsonObject torchsoul = new com.google.gson.JsonObject();
		com.google.gson.JsonObject cart = new com.google.gson.JsonObject();
		com.google.gson.JsonObject fletch = new com.google.gson.JsonObject();
		com.google.gson.JsonObject smith = new com.google.gson.JsonObject();
		com.google.gson.JsonObject loom = new com.google.gson.JsonObject();
		com.google.gson.JsonObject camp = new com.google.gson.JsonObject();
		com.google.gson.JsonObject soulcampo = new com.google.gson.JsonObject();
		com.google.gson.JsonObject scaff = new com.google.gson.JsonObject();
		com.google.gson.JsonObject compostor = new com.google.gson.JsonObject();
		com.google.gson.JsonObject astand = new com.google.gson.JsonObject();
		com.google.gson.JsonObject glowframe = new com.google.gson.JsonObject();
		com.google.gson.JsonObject frame = new com.google.gson.JsonObject();
		com.google.gson.JsonObject paint = new com.google.gson.JsonObject();
		com.google.gson.JsonObject lect = new com.google.gson.JsonObject();
		com.google.gson.JsonObject flowers = new com.google.gson.JsonObject();
		com.google.gson.JsonObject leaves = new com.google.gson.JsonObject();
		com.google.gson.JsonObject blaze = new com.google.gson.JsonObject();
		com.google.gson.JsonObject cItemOBJ = new com.google.gson.JsonObject();
		configFile = new File((FMLPaths.GAMEDIR.get().toString() + "/config/euru/"), File.separator + "euru_fe_config.json");
		cVer = EuruModVariables.cVer;
		if (!configFile.exists()) {
			try {
				configFile.getParentFile().mkdirs();
				configFile.createNewFile();
			} catch (IOException exception) {
				exception.printStackTrace();
			} // blaze
			cItemOBJ = new com.google.gson.JsonObject();
			cItem = BuiltInRegistries.ITEM.getKey(Items.BLAZE_ROD).toString();
			cItemOBJ.addProperty("feGenerated", 20000);
			cItemOBJ.addProperty("feSpeed", 5);
			fuelPropertiesOBJ.add(cItem, cItemOBJ);
			sArray.add(cItem);// listFuel
			sArray.add("minecraft:coals");
			sArray.add("minecraft:saplings");
			sArray.add("minecraft:logs");
			sArray.add("minecraft:planks");
			sArray.add((BuiltInRegistries.ITEM.getKey(Items.STICK).toString()));
			sArray.add("minecraft:wool");
			sArray.add("minecraft:wool_carpets");
			sArray.add((BuiltInRegistries.ITEM.getKey(Blocks.DAYLIGHT_DETECTOR.asItem()).toString()));
			sArray.add((BuiltInRegistries.ITEM.getKey(Items.WOODEN_AXE).toString()));
			sArray.add((BuiltInRegistries.ITEM.getKey(Items.WOODEN_SWORD).toString()));
			sArray.add((BuiltInRegistries.ITEM.getKey(Items.WOODEN_PICKAXE).toString()));
			sArray.add((BuiltInRegistries.ITEM.getKey(Items.WOODEN_SHOVEL).toString()));
			sArray.add((BuiltInRegistries.ITEM.getKey(Items.WOODEN_HOE).toString()));
			sArray.add((BuiltInRegistries.ITEM.getKey(Items.SHIELD).toString()));
			sArray.add((BuiltInRegistries.ITEM.getKey(Items.CARROT_ON_A_STICK).toString()));
			sArray.add((BuiltInRegistries.ITEM.getKey(Items.WARPED_FUNGUS_ON_A_STICK).toString()));
			sArray.add((BuiltInRegistries.ITEM.getKey(Blocks.BOOKSHELF.asItem()).toString()));
			sArray.add((BuiltInRegistries.ITEM.getKey(Blocks.CHISELED_BOOKSHELF.asItem()).toString()));
			sArray.add("minecraft:wooden_buttons");
			sArray.add("minecraft:wooden_doors");
			sArray.add("minecraft:wooden_fences");
			sArray.add("minecraft:wooden_pressure_plates");
			sArray.add("minecraft:wooden_slabs");
			sArray.add("minecraft:wooden_stairs");
			sArray.add("minecraft:wooden_trapdoors");
			sArray.add((BuiltInRegistries.ITEM.getKey(Blocks.COAL_BLOCK.asItem()).toString()));
			sArray.add((BuiltInRegistries.ITEM.getKey(Blocks.CRAFTING_TABLE.asItem()).toString()));
			sArray.add((BuiltInRegistries.ITEM.getKey(Blocks.CHEST.asItem()).toString()));
			sArray.add((BuiltInRegistries.ITEM.getKey(Blocks.TRAPPED_CHEST.asItem()).toString()));
			sArray.add((BuiltInRegistries.ITEM.getKey(Blocks.LADDER.asItem()).toString()));
			sArray.add((BuiltInRegistries.ITEM.getKey(Blocks.JUKEBOX.asItem()).toString()));
			sArray.add((BuiltInRegistries.ITEM.getKey(Blocks.BEEHIVE.asItem()).toString()));
			sArray.add("minecraft:beds");
			sArray.add((BuiltInRegistries.ITEM.getKey(Items.BOWL).toString()));
			sArray.add("minecraft:signs");
			sArray.add("minecraft:boats");
			sArray.add((BuiltInRegistries.ITEM.getKey(Items.BOW).toString()));
			sArray.add((BuiltInRegistries.ITEM.getKey(Items.CROSSBOW).toString()));
			sArray.add((BuiltInRegistries.ITEM.getKey(Items.TORCH).toString()));
			sArray.add((BuiltInRegistries.ITEM.getKey(Items.REDSTONE_TORCH).toString()));
			sArray.add((BuiltInRegistries.ITEM.getKey(Items.SOUL_TORCH).toString()));
			sArray.add((BuiltInRegistries.ITEM.getKey(Blocks.CARTOGRAPHY_TABLE.asItem()).toString()));
			sArray.add((BuiltInRegistries.ITEM.getKey(Blocks.FLETCHING_TABLE.asItem()).toString()));
			sArray.add((BuiltInRegistries.ITEM.getKey(Blocks.SMITHING_TABLE.asItem()).toString()));
			sArray.add((BuiltInRegistries.ITEM.getKey(Blocks.LOOM.asItem()).toString()));
			sArray.add((BuiltInRegistries.ITEM.getKey(Blocks.CAMPFIRE.asItem()).toString()));
			sArray.add((BuiltInRegistries.ITEM.getKey(Blocks.SOUL_CAMPFIRE.asItem()).toString()));
			sArray.add((BuiltInRegistries.ITEM.getKey(Blocks.SCAFFOLDING.asItem()).toString()));
			sArray.add((BuiltInRegistries.ITEM.getKey(Blocks.COMPOSTER.asItem()).toString()));
			sArray.add((BuiltInRegistries.ITEM.getKey(Items.ARMOR_STAND).toString()));
			sArray.add((BuiltInRegistries.ITEM.getKey(Items.GLOW_ITEM_FRAME).toString()));
			sArray.add((BuiltInRegistries.ITEM.getKey(Items.ITEM_FRAME).toString()));
			sArray.add((BuiltInRegistries.ITEM.getKey(Items.PAINTING).toString()));
			sArray.add((BuiltInRegistries.ITEM.getKey(Blocks.LECTERN.asItem()).toString()));
			sArray.add("minecraft:flowers");
			sArray.add("minecraft:leaves");// fuelProperties
			// leaves
			leaves.addProperty("feGenerated", 80);
			leaves.addProperty("feSpeed", 5);
			fuelPropertiesOBJ.add("minecraft:leaves", leaves);// flowers
			flowers.addProperty("feGenerated", 80);
			flowers.addProperty("feSpeed", 5);
			fuelPropertiesOBJ.add("minecraft:flowers", flowers);// lectern
			lect.addProperty("feGenerated", 350);
			lect.addProperty("feSpeed", 5);
			fuelPropertiesOBJ.add((BuiltInRegistries.ITEM.getKey(Blocks.LECTERN.asItem()).toString()), lect);// painting
			paint.addProperty("feGenerated", 200);
			paint.addProperty("feSpeed", 5);
			fuelPropertiesOBJ.add((BuiltInRegistries.ITEM.getKey(Items.PAINTING).toString()), paint);// frame
			frame.addProperty("feGenerated", 200);
			frame.addProperty("feSpeed", 5);
			fuelPropertiesOBJ.add((BuiltInRegistries.ITEM.getKey(Items.ITEM_FRAME).toString()), frame);// glowframe
			glowframe.addProperty("feGenerated", 200);
			glowframe.addProperty("feSpeed", 5);
			fuelPropertiesOBJ.add((BuiltInRegistries.ITEM.getKey(Items.GLOW_ITEM_FRAME).toString()), glowframe);// armorstand
			astand.addProperty("feGenerated", 200);
			astand.addProperty("feSpeed", 5);
			fuelPropertiesOBJ.add((BuiltInRegistries.ITEM.getKey(Items.ARMOR_STAND).toString()), astand);// composter
			compostor.addProperty("feGenerated", 350);
			compostor.addProperty("feSpeed", 5);
			fuelPropertiesOBJ.add((BuiltInRegistries.ITEM.getKey(Blocks.COMPOSTER.asItem()).toString()), compostor);// scaffolding
			scaff.addProperty("feGenerated", 350);
			scaff.addProperty("feSpeed", 5);
			fuelPropertiesOBJ.add((BuiltInRegistries.ITEM.getKey(Blocks.SCAFFOLDING.asItem()).toString()), scaff);// soulcamp
			soulcampo.addProperty("feGenerated", 350);
			soulcampo.addProperty("feSpeed", 5);
			fuelPropertiesOBJ.add((BuiltInRegistries.ITEM.getKey(Blocks.SOUL_CAMPFIRE.asItem()).toString()), soulcampo);// campfire
			camp.addProperty("feGenerated", 350);
			camp.addProperty("feSpeed", 5);
			fuelPropertiesOBJ.add((BuiltInRegistries.ITEM.getKey(Blocks.CAMPFIRE.asItem()).toString()), camp);// smith
			loom.addProperty("feGenerated", 350);
			loom.addProperty("feSpeed", 5);
			fuelPropertiesOBJ.add((BuiltInRegistries.ITEM.getKey(Blocks.LOOM.asItem()).toString()), loom);// smith
			smith.addProperty("feGenerated", 350);
			smith.addProperty("feSpeed", 5);
			fuelPropertiesOBJ.add((BuiltInRegistries.ITEM.getKey(Blocks.SMITHING_TABLE.asItem()).toString()), smith);// fletch
			fletch.addProperty("feGenerated", 350);
			fletch.addProperty("feSpeed", 5);
			fuelPropertiesOBJ.add((BuiltInRegistries.ITEM.getKey(Blocks.FLETCHING_TABLE.asItem()).toString()), fletch);// cart
			cart.addProperty("feGenerated", 350);
			cart.addProperty("feSpeed", 5);
			fuelPropertiesOBJ.add((BuiltInRegistries.ITEM.getKey(Blocks.CARTOGRAPHY_TABLE.asItem()).toString()), cart);// torch
			torch.addProperty("feGenerated", 100);
			torch.addProperty("feSpeed", 5);
			fuelPropertiesOBJ.add((BuiltInRegistries.ITEM.getKey(Items.TORCH).toString()), torch);// redtorch
			torchred.addProperty("feGenerated", 100);
			torchred.addProperty("feSpeed", 5);
			fuelPropertiesOBJ.add((BuiltInRegistries.ITEM.getKey(Items.REDSTONE_TORCH).toString()), torchred);// soultorch
			torchsoul.addProperty("feGenerated", 100);
			torchsoul.addProperty("feSpeed", 5);
			fuelPropertiesOBJ.add((BuiltInRegistries.ITEM.getKey(Items.SOUL_TORCH).toString()), torchsoul);// beehive
			beehive.addProperty("feGenerated", 400);
			beehive.addProperty("feSpeed", 5);
			fuelPropertiesOBJ.add((BuiltInRegistries.ITEM.getKey(Blocks.BEEHIVE.asItem()).toString()), beehive);// minecraft:beds
			beds.addProperty("feGenerated", 600);
			beds.addProperty("feSpeed", 5);
			fuelPropertiesOBJ.add("minecraft:beds", beds);// cbow
			cbow.addProperty("feGenerated", 200);
			cbow.addProperty("feSpeed", 5);
			fuelPropertiesOBJ.add((BuiltInRegistries.ITEM.getKey(Items.CROSSBOW).toString()), cbow);// bow
			bow.addProperty("feGenerated", 200);
			bow.addProperty("feSpeed", 5);
			fuelPropertiesOBJ.add((BuiltInRegistries.ITEM.getKey(Items.BOW).toString()), bow);// boats
			boats.addProperty("feGenerated", 350);
			boats.addProperty("feSpeed", 5);
			fuelPropertiesOBJ.add("minecraft:boats", boats);// minecraft:signs
			signs.addProperty("feGenerated", 350);
			signs.addProperty("feSpeed", 5);
			fuelPropertiesOBJ.add("minecraft:signs", signs);// bowl
			bowl.addProperty("feGenerated", 200);
			bowl.addProperty("feSpeed", 5);
			fuelPropertiesOBJ.add((BuiltInRegistries.ITEM.getKey(Items.BOWL).toString()), bowl);// juke
			juke.addProperty("feGenerated", 350);
			juke.addProperty("feSpeed", 5);
			fuelPropertiesOBJ.add((BuiltInRegistries.ITEM.getKey(Blocks.JUKEBOX.asItem()).toString()), juke);// ladder
			ladder.addProperty("feGenerated", 350);
			ladder.addProperty("feSpeed", 5);
			fuelPropertiesOBJ.add((BuiltInRegistries.ITEM.getKey(Blocks.LADDER.asItem()).toString()), ladder);// tchest
			tchest.addProperty("feGenerated", 700);
			tchest.addProperty("feSpeed", 5);
			fuelPropertiesOBJ.add((BuiltInRegistries.ITEM.getKey(Blocks.TRAPPED_CHEST.asItem()).toString()), tchest);// chest
			chest.addProperty("feGenerated", 700);
			chest.addProperty("feSpeed", 5);
			fuelPropertiesOBJ.add((BuiltInRegistries.ITEM.getKey(Blocks.CHEST.asItem()).toString()), chest);// craft
			craft.addProperty("feGenerated", 350);
			craft.addProperty("feSpeed", 5);
			fuelPropertiesOBJ.add((BuiltInRegistries.ITEM.getKey(Blocks.CRAFTING_TABLE.asItem()).toString()), craft);// coalblock
			coalblock.addProperty("feGenerated", 23000);
			coalblock.addProperty("feSpeed", 5);
			fuelPropertiesOBJ.add((BuiltInRegistries.ITEM.getKey(Blocks.COAL_BLOCK.asItem()).toString()), coalblock);// minecraft:wooden_trapdoors
			wooden_trapdoors.addProperty("feGenerated", 350);
			wooden_trapdoors.addProperty("feSpeed", 5);
			fuelPropertiesOBJ.add("minecraft:wooden_trapdoors", wooden_trapdoors);// minecraft:wooden_stairs
			wooden_stairs.addProperty("feGenerated", 350);
			wooden_stairs.addProperty("feSpeed", 5);
			fuelPropertiesOBJ.add("minecraft:wooden_stairs", wooden_stairs);// minecraft:wooden_slabs
			wooden_slabs.addProperty("feGenerated", 175);
			wooden_slabs.addProperty("feSpeed", 5);
			fuelPropertiesOBJ.add("minecraft:wooden_slabs", wooden_slabs);// wooden_pressure_plates
			wooden_pressure_plates.addProperty("feGenerated", 200);
			wooden_pressure_plates.addProperty("feSpeed", 5);
			fuelPropertiesOBJ.add("minecraft:wooden_pressure_plates", wooden_pressure_plates);// minecraft:wooden_fences
			wooden_fences.addProperty("feGenerated", 450);
			wooden_fences.addProperty("feSpeed", 5);
			fuelPropertiesOBJ.add("minecraft:wooden_fences", wooden_fences);// minecraft:wooden_doors
			wooden_doors.addProperty("feGenerated", 450);
			wooden_doors.addProperty("feSpeed", 5);
			fuelPropertiesOBJ.add("minecraft:wooden_doors", wooden_doors);// minecraft:wooden_buttons
			button.addProperty("feGenerated", 80);
			button.addProperty("feSpeed", 5);
			fuelPropertiesOBJ.add("minecraft:wooden_buttons", button);// cbookshelf
			cbookshelf.addProperty("feGenerated", 200);
			cbookshelf.addProperty("feSpeed", 5);
			fuelPropertiesOBJ.add((BuiltInRegistries.ITEM.getKey(Blocks.CHISELED_BOOKSHELF.asItem()).toString()), cbookshelf);// bookshelf
			bookshelf.addProperty("feGenerated", 200);
			bookshelf.addProperty("feSpeed", 5);
			fuelPropertiesOBJ.add((BuiltInRegistries.ITEM.getKey(Blocks.BOOKSHELF.asItem()).toString()), bookshelf);// stickwarp
			warpstick.addProperty("feGenerated", 200);
			warpstick.addProperty("feSpeed", 5);
			fuelPropertiesOBJ.add((BuiltInRegistries.ITEM.getKey(Items.WARPED_FUNGUS_ON_A_STICK).toString()), warpstick);// stickcarrot
			stickcarrot.addProperty("feGenerated", 200);
			stickcarrot.addProperty("feSpeed", 5);
			fuelPropertiesOBJ.add((BuiltInRegistries.ITEM.getKey(Items.CARROT_ON_A_STICK).toString()), stickcarrot);// shield
			shield.addProperty("feGenerated", 1200);
			shield.addProperty("feSpeed", 5);
			fuelPropertiesOBJ.add((BuiltInRegistries.ITEM.getKey(Items.SHIELD).toString()), shield);// whoe
			whoe.addProperty("feGenerated", 400);
			whoe.addProperty("feSpeed", 5);
			fuelPropertiesOBJ.add((BuiltInRegistries.ITEM.getKey(Items.WOODEN_HOE).toString()), whoe);// wsho
			wsho.addProperty("feGenerated", 400);
			wsho.addProperty("feSpeed", 5);
			fuelPropertiesOBJ.add((BuiltInRegistries.ITEM.getKey(Items.WOODEN_SHOVEL).toString()), wsho);// wpick
			wpick.addProperty("feGenerated", 400);
			wpick.addProperty("feSpeed", 5);
			fuelPropertiesOBJ.add((BuiltInRegistries.ITEM.getKey(Items.WOODEN_PICKAXE).toString()), wpick);// waxe
			waxe.addProperty("feGenerated", 400);
			waxe.addProperty("feSpeed", 5);
			fuelPropertiesOBJ.add((BuiltInRegistries.ITEM.getKey(Items.WOODEN_AXE).toString()), waxe);// wsword
			wsword.addProperty("feGenerated", 400);
			wsword.addProperty("feSpeed", 5);
			fuelPropertiesOBJ.add((BuiltInRegistries.ITEM.getKey(Items.WOODEN_SWORD).toString()), wsword);// daylight
			day.addProperty("feGenerated", 400);
			day.addProperty("feSpeed", 5);
			fuelPropertiesOBJ.add((BuiltInRegistries.ITEM.getKey(Blocks.DAYLIGHT_DETECTOR.asItem()).toString()), day);// minecraft:wool_carpets
			carpet.addProperty("feGenerated", 100);
			carpet.addProperty("feSpeed", 5);
			fuelPropertiesOBJ.add("minecraft:wool_carpets", carpet);// minecraft:wool
			wool.addProperty("feGenerated", 200);
			wool.addProperty("feSpeed", 5);
			fuelPropertiesOBJ.add("minecraft:wool", wool);// stick
			stickobj.addProperty("feGenerated", 100);
			stickobj.addProperty("feSpeed", 5);
			fuelPropertiesOBJ.add((BuiltInRegistries.ITEM.getKey(Items.STICK).toString()), stickobj);// planks
			planksobj.addProperty("feGenerated", 350);
			planksobj.addProperty("feSpeed", 5);
			fuelPropertiesOBJ.add("minecraft:planks", planksobj);// Logs
			logsobj.addProperty("feGenerated", 350);
			logsobj.addProperty("feSpeed", 5);
			fuelPropertiesOBJ.add("minecraft:logs", logsobj);// Coal
			coalOBJ.addProperty("feGenerated", 2500);
			coalOBJ.addProperty("feSpeed", 5);
			fuelPropertiesOBJ.add("minecraft:coals", coalOBJ);// Saplings
			saplingsobj.addProperty("feGenerated", 175);
			saplingsobj.addProperty("feSpeed", 5);
			fuelPropertiesOBJ.add("minecraft:saplings", saplingsobj);// surGen
			configJsonObject.add((BuiltInRegistries.ITEM.getKey(EuruModBlocks.SURVIVAL_GENERATOR.get().asItem()).toString()), configSubJsonObjest);
			configSubJsonObjest.add("listFuel", sArray);
			configSubJsonObjest.add("fuelProperties", fuelPropertiesOBJ);
			configJsonObject.addProperty("config_version", cVer);
			{
				com.google.gson.Gson mainGSONBuilderVariable = new com.google.gson.GsonBuilder().setPrettyPrinting().create();
				try {
					FileWriter fileWriter = new FileWriter(configFile);
					fileWriter.write(mainGSONBuilderVariable.toJson(configJsonObject));
					fileWriter.close();
				} catch (IOException exception) {
					exception.printStackTrace();
				}
			}
		} else {
			{
				try {
					BufferedReader bufferedReader = new BufferedReader(new FileReader(configFile));
					StringBuilder jsonstringbuilder = new StringBuilder();
					String line;
					while ((line = bufferedReader.readLine()) != null) {
						jsonstringbuilder.append(line);
					}
					bufferedReader.close();
					configJsonObject = new com.google.gson.Gson().fromJson(jsonstringbuilder.toString(), com.google.gson.JsonObject.class);
					if (configJsonObject.get("config_version").isJsonPrimitive() ? configJsonObject.get("config_version").getAsJsonPrimitive().isNumber() : false) {
						if (configJsonObject.get("config_version").getAsDouble() != cVer) {
							configFile.delete();
							EURUGeneratorsManagerProcedure.execute();
						}
					} else {
						configFile.delete();
						EURUGeneratorsManagerProcedure.execute();
					}
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}
}