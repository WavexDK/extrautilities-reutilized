package net.wavedk.extrautilitiesreutilized.procedures;

import net.wavedk.extrautilitiesreutilized.network.EuruModVariables;

import net.neoforged.neoforge.event.tick.PlayerTickEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.bus.api.Event;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.Entity;

import javax.annotation.Nullable;

@EventBusSubscriber
public class PlayerGPTickUpdateProcedure {
	@SubscribeEvent
	public static void onPlayerTick(PlayerTickEvent.Post event) {
		execute(event, event.getEntity().level(), event.getEntity());
	}

	public static void execute(LevelAccessor world, Entity entity) {
		execute(null, world, entity);
	}

	private static void execute(@Nullable Event event, LevelAccessor world, Entity entity) {
		if (entity == null)
			return;
		double solarPanelCutOff = 0;
		if (entity.getData(EuruModVariables.PLAYER_VARIABLES).playerGPTickUpdateCounter < 5) {
			{
				EuruModVariables.PlayerVariables _vars = entity.getData(EuruModVariables.PLAYER_VARIABLES);
				_vars.playerGPTickUpdateCounter = entity.getData(EuruModVariables.PLAYER_VARIABLES).playerGPTickUpdateCounter + 1;
				_vars.markSyncDirty();
			}
			GPOverlayTickProcedure.execute(world, entity);
		} else {
			if (entity.getData(EuruModVariables.PLAYER_VARIABLES).playerGPChecking == false) {
				{
					EuruModVariables.PlayerVariables _vars = entity.getData(EuruModVariables.PLAYER_VARIABLES);
					_vars.playerGPChecking = true;
					_vars.markSyncDirty();
				}
				GPOverlayTickProcedure.execute(world, entity);
				{
					EuruModVariables.PlayerVariables _vars = entity.getData(EuruModVariables.PLAYER_VARIABLES);
					_vars.group_raw_solarpanels = 0;
					_vars.group_count_solarpanels = 0;
					_vars.markSyncDirty();
				}
			} else {
				{
					EuruModVariables.PlayerVariables _vars = entity.getData(EuruModVariables.PLAYER_VARIABLES);
					_vars.playerGP_Used = entity.getData(EuruModVariables.PLAYER_VARIABLES).playerGP_Used_Update;
					_vars.playerGP_Used_Update = 0;
					_vars.playerGPChecking = false;
					_vars.playerGPTickUpdateCounter = 1;
					_vars.playerGPUpdateTotal = 0;
					_vars.markSyncDirty();
				}
				UpdategroupsolarpanelsProcedure.execute(entity);
				{
					EuruModVariables.PlayerVariables _vars = entity.getData(EuruModVariables.PLAYER_VARIABLES);
					_vars.playerGP_Total = entity.getData(EuruModVariables.PLAYER_VARIABLES).playerGPUpdateTotal;
					_vars.markSyncDirty();
				}
				GPOverlayTickProcedure.execute(world, entity);
			}
		}
	}
}