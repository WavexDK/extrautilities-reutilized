package net.wavedk.extrautilitiesreutilized.procedures;

import org.checkerframework.checker.units.qual.A;

import org.apache.commons.lang3.function.FailableFunction;

import net.wavedk.extrautilitiesreutilized.network.EuruModVariables;

import net.neoforged.fml.loading.FMLPaths;

import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Entity;
import net.minecraft.util.RandomSource;
import net.minecraft.util.Mth;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.BlockPos;

import java.util.function.Supplier;
import java.util.UUID;

import java.io.IOException;
import java.io.FileReader;
import java.io.File;
import java.io.BufferedReader;

public class ChunkLoaderTickUpdateProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z) {
		Entity player = null;
		String placedBy = "";
		File file = new File("");
		com.google.gson.JsonObject obj = new com.google.gson.JsonObject();
		com.google.gson.JsonObject blockobj = new com.google.gson.JsonObject();
		if (!EuruModVariables.WorldVariables.get(world).chunksloaded.contains(((getBlockNBTString(world, BlockPos.containing(x, y, z), "placedBy") + ".") + ""
				+ ((world instanceof Level _lvl ? _lvl.dimension() : (world instanceof WorldGenLevel _wgl ? _wgl.getLevel().dimension() : Level.OVERWORLD)) + ",") + (x + " ") + (y + " ") + z))) {
			placedBy = getBlockNBTString(world, BlockPos.containing(x, y, z), "placedBy");
			if (world.getServer() != null) {
				LevelAccessor _origWorld = world;
				for (ServerLevel worlditerator : world.getServer().getAllLevels()) {
					world = worlditerator;
					player = world instanceof ServerLevel _serverGetEntityUUID ? _serverGetEntityUUID.getEntity(tryOrDefault(placedBy, UUID::fromString, () -> new UUID(0, 0))) : null;
					if (player instanceof ServerPlayer || player instanceof Player) {
						break;
					}
				}
				world = _origWorld;
			}
			if (player instanceof ServerPlayer || player instanceof Player) {
				if (player.getData(EuruModVariables.PLAYER_VARIABLES).playerGP_Used <= player.getData(EuruModVariables.PLAYER_VARIABLES).playerGP_Total && !player.getData(EuruModVariables.PLAYER_VARIABLES).playerGPChecking) {
					EuruModVariables.WorldVariables.get(world).chunksloaded.add(((getBlockNBTString(world, BlockPos.containing(x, y, z), "placedBy") + ".") + ""
							+ ((world instanceof Level _lvl ? _lvl.dimension() : (world instanceof WorldGenLevel _wgl ? _wgl.getLevel().dimension() : Level.OVERWORLD)) + ",") + (x + " ") + (y + " ") + z));
					EuruModVariables.WorldVariables.get(world).markSyncDirty();
				}
			}
		} else {
			placedBy = getBlockNBTString(world, BlockPos.containing(x, y, z), "placedBy");
			if (world.getServer() != null) {
				LevelAccessor _origWorld = world;
				for (ServerLevel worlditerator : world.getServer().getAllLevels()) {
					world = worlditerator;
					player = world instanceof ServerLevel _serverGetEntityUUID ? _serverGetEntityUUID.getEntity(tryOrDefault(placedBy, UUID::fromString, () -> new UUID(0, 0))) : null;
					if (player instanceof ServerPlayer || player instanceof Player) {
						break;
					}
				}
				world = _origWorld;
			}
			if (player.getData(EuruModVariables.PLAYER_VARIABLES).playerGPChecking) {
				if (getBlockNBTNumber(world, BlockPos.containing(x, y, z), "gp_needed") == 0 || getBlockNBTNumber(world, BlockPos.containing(x, y, z), "check_counter") > Mth.nextInt(RandomSource.create(), 80, 110)) {
					file = new File((FMLPaths.GAMEDIR.get().toString() + "/config/euru/"), File.separator + "euru_config.json");
					{
						try {
							BufferedReader bufferedReader = new BufferedReader(new FileReader(file));
							StringBuilder jsonstringbuilder = new StringBuilder();
							String line;
							while ((line = bufferedReader.readLine()) != null) {
								jsonstringbuilder.append(line);
							}
							bufferedReader.close();
							obj = new com.google.gson.Gson().fromJson(jsonstringbuilder.toString(), com.google.gson.JsonObject.class);
							blockobj = obj.get((BuiltInRegistries.BLOCK.getKey((world.getBlockState(BlockPos.containing(x, y, z))).getBlock()).toString())).getAsJsonObject();
							setBlockNBTNumber(world, x, y, z, "gp_needed", blockobj.get("gp_needed").getAsDouble());
						} catch (IOException e) {
							e.printStackTrace();
						}
					}
					setBlockNBTNumber(world, x, y, z, "check_counter", 1);
				} else {
					setBlockNBTNumber(world, x, y, z, "check_counter", (getBlockNBTNumber(world, BlockPos.containing(x, y, z), "check_counter") + 1));
				}
				{
					EuruModVariables.PlayerVariables _vars = player.getData(EuruModVariables.PLAYER_VARIABLES);
					_vars.playerGP_Used_Update = player.getData(EuruModVariables.PLAYER_VARIABLES).playerGP_Used_Update + getBlockNBTNumber(world, BlockPos.containing(x, y, z), "gp_needed");
					_vars.markSyncDirty();
				}
			}
		}
	}

	private static String getBlockNBTString(LevelAccessor world, BlockPos pos, String tag) {
		BlockEntity blockEntity = world.getBlockEntity(pos);
		if (blockEntity != null)
			return blockEntity.getPersistentData().getStringOr(tag, "");
		return "";
	}

	private static <A, B> A tryOrDefault(B funcArg, FailableFunction<B, A, Exception> func, Supplier<A> fallback) {
		try {
			return func.apply(funcArg);
		} catch (Exception e) {
			return fallback.get();
		}
	}

	private static double getBlockNBTNumber(LevelAccessor world, BlockPos pos, String tag) {
		BlockEntity blockEntity = world.getBlockEntity(pos);
		if (blockEntity != null)
			return blockEntity.getPersistentData().getDoubleOr(tag, 0);
		return -1;
	}

	private static void setBlockNBTNumber(LevelAccessor world, double x, double y, double z, String tag, double value) {
		if (!world.isClientSide()) {
			BlockPos pos = BlockPos.containing(x, y, z);
			BlockEntity blockEntity = world.getBlockEntity(pos);
			BlockState blockState = world.getBlockState(pos);
			if (blockEntity != null) {
				blockEntity.getPersistentData().putDouble(tag, value);
			}
			if (world instanceof Level level) {
				level.sendBlockUpdated(pos, blockState, blockState, 3);
			}
		}
	}
}