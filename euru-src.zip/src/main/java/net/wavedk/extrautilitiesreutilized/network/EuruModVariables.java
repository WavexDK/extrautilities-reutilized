package net.wavedk.extrautilitiesreutilized.network;

import net.wavedk.extrautilitiesreutilized.EuruMod;

import net.neoforged.neoforge.registries.NeoForgeRegistries;
import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.network.handling.IPayloadContext;
import net.neoforged.neoforge.network.PacketDistributor;
import net.neoforged.neoforge.event.tick.PlayerTickEvent;
import net.neoforged.neoforge.event.tick.LevelTickEvent;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;
import net.neoforged.neoforge.common.util.ValueIOSerializable;
import net.neoforged.neoforge.attachment.AttachmentType;
import net.neoforged.fml.event.lifecycle.FMLCommonSetupEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.level.storage.ValueOutput;
import net.minecraft.world.level.storage.ValueInput;
import net.minecraft.world.level.storage.TagValueOutput;
import net.minecraft.world.level.storage.TagValueInput;
import net.minecraft.world.level.saveddata.SavedDataType;
import net.minecraft.world.level.saveddata.SavedData;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.world.entity.Entity;
import net.minecraft.util.ProblemReporter;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.network.protocol.PacketFlow;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.chat.Component;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.core.HolderLookup;

import java.util.function.Supplier;
import java.util.ArrayList;

@EventBusSubscriber
public class EuruModVariables {
	public static final DeferredRegister<AttachmentType<?>> ATTACHMENT_TYPES = DeferredRegister.create(NeoForgeRegistries.Keys.ATTACHMENT_TYPES, EuruMod.MODID);
	public static final Supplier<AttachmentType<PlayerVariables>> PLAYER_VARIABLES = ATTACHMENT_TYPES.register("player_variables", () -> AttachmentType.serializable(() -> new PlayerVariables()).build());
	public static double cVer = 1.0;

	@SubscribeEvent
	public static void init(FMLCommonSetupEvent event) {
		EuruMod.addNetworkMessage(SavedDataSyncMessage.TYPE, SavedDataSyncMessage.STREAM_CODEC, SavedDataSyncMessage::handleData);
		EuruMod.addNetworkMessage(PlayerVariablesSyncMessage.TYPE, PlayerVariablesSyncMessage.STREAM_CODEC, PlayerVariablesSyncMessage::handleData);
	}

	@SubscribeEvent
	public static void onPlayerLoggedInSyncPlayerVariables(PlayerEvent.PlayerLoggedInEvent event) {
		if (event.getEntity() instanceof ServerPlayer player) {
			for (Entity entityiterator : player.level().players())
				if (entityiterator != player && entityiterator instanceof ServerPlayer playeriterator)
					PacketDistributor.sendToPlayer(player, new PlayerVariablesSyncMessage(playeriterator.getData(PLAYER_VARIABLES), playeriterator.getId()));
			PacketDistributor.sendToPlayersInDimension(player.level(), new PlayerVariablesSyncMessage(player.getData(PLAYER_VARIABLES), player.getId()));
		}
	}

	@SubscribeEvent
	public static void onPlayerRespawnedSyncPlayerVariables(PlayerEvent.PlayerRespawnEvent event) {
		if (event.getEntity() instanceof ServerPlayer player) {
			for (Entity entityiterator : player.level().players())
				if (entityiterator != player && entityiterator instanceof ServerPlayer playeriterator)
					PacketDistributor.sendToPlayer(player, new PlayerVariablesSyncMessage(playeriterator.getData(PLAYER_VARIABLES), playeriterator.getId()));
			PacketDistributor.sendToPlayersInDimension(player.level(), new PlayerVariablesSyncMessage(player.getData(PLAYER_VARIABLES), player.getId()));
		}
	}

	@SubscribeEvent
	public static void onPlayerChangedDimensionSyncPlayerVariables(PlayerEvent.PlayerChangedDimensionEvent event) {
		if (event.getEntity() instanceof ServerPlayer player) {
			for (Entity entityiterator : player.level().players())
				if (entityiterator != player && entityiterator instanceof ServerPlayer playeriterator)
					PacketDistributor.sendToPlayer(player, new PlayerVariablesSyncMessage(playeriterator.getData(PLAYER_VARIABLES), playeriterator.getId()));
			PacketDistributor.sendToPlayersInDimension(player.level(), new PlayerVariablesSyncMessage(player.getData(PLAYER_VARIABLES), player.getId()));
		}
	}

	@SubscribeEvent
	public static void onPlayerTickUpdateSyncPlayerVariables(PlayerTickEvent.Post event) {
		if (event.getEntity() instanceof ServerPlayer player && player.getData(PLAYER_VARIABLES)._syncDirty) {
			PacketDistributor.sendToPlayersInDimension(player.level(), new PlayerVariablesSyncMessage(player.getData(PLAYER_VARIABLES), player.getId()));
			player.getData(PLAYER_VARIABLES)._syncDirty = false;
		}
	}

	@SubscribeEvent
	public static void clonePlayer(PlayerEvent.Clone event) {
		PlayerVariables original = event.getOriginal().getData(PLAYER_VARIABLES);
		PlayerVariables clone = new PlayerVariables();
		clone.playerGP_Total = original.playerGP_Total;
		clone.playerGP_Used = original.playerGP_Used;
		clone.playerGPTickUpdateCounter = original.playerGPTickUpdateCounter;
		clone.playerGPChecking = original.playerGPChecking;
		clone.playerGPUpdateTotal = original.playerGPUpdateTotal;
		clone.group_raw_solarpanels = original.group_raw_solarpanels;
		clone.group_count_solarpanels = original.group_count_solarpanels;
		clone.playerGP_Used_Update = original.playerGP_Used_Update;
		clone.group_cutoff_solarpanels = original.group_cutoff_solarpanels;
		clone.playerAB1 = original.playerAB1;
		clone.playerAB2 = original.playerAB2;
		clone.changeAB = original.changeAB;
		clone.overlayCounter = original.overlayCounter;
		clone.group_update_solarpanels = original.group_update_solarpanels;
		clone.group_efficiency_solarpanels = original.group_efficiency_solarpanels;
		clone.changingAB1 = original.changingAB1;
		clone.changingAB2 = original.changingAB2;
		clone.playerGP_Total_SI = original.playerGP_Total_SI;
		clone.playerGP_Used_SI = original.playerGP_Used_SI;
		clone.randomGPCounter = original.randomGPCounter;
		if (!event.isWasDeath()) {
		}
		event.getEntity().setData(PLAYER_VARIABLES, clone);
	}

	@SubscribeEvent
	public static void onPlayerLoggedIn(PlayerEvent.PlayerLoggedInEvent event) {
		if (event.getEntity() instanceof ServerPlayer player) {
			SavedData mapdata = MapVariables.get(event.getEntity().level());
			SavedData worlddata = WorldVariables.get(event.getEntity().level());
			if (mapdata != null)
				PacketDistributor.sendToPlayer(player, new SavedDataSyncMessage(0, mapdata));
			if (worlddata != null)
				PacketDistributor.sendToPlayer(player, new SavedDataSyncMessage(1, worlddata));
		}
	}

	@SubscribeEvent
	public static void onPlayerChangedDimension(PlayerEvent.PlayerChangedDimensionEvent event) {
		if (event.getEntity() instanceof ServerPlayer player) {
			SavedData worlddata = WorldVariables.get(event.getEntity().level());
			if (worlddata != null)
				PacketDistributor.sendToPlayer(player, new SavedDataSyncMessage(1, worlddata));
		}
	}

	@SubscribeEvent
	public static void onWorldTick(LevelTickEvent.Post event) {
		if (event.getLevel() instanceof ServerLevel level) {
			WorldVariables worldVariables = WorldVariables.get(level);
			if (worldVariables._syncDirty) {
				PacketDistributor.sendToPlayersInDimension(level, new SavedDataSyncMessage(1, worldVariables));
				worldVariables._syncDirty = false;
			}
			MapVariables mapVariables = MapVariables.get(level);
			if (mapVariables._syncDirty) {
				PacketDistributor.sendToAllPlayers(new SavedDataSyncMessage(0, mapVariables));
				mapVariables._syncDirty = false;
			}
		}
	}

	public static class WorldVariables extends SavedData {
		public static final SavedDataType<WorldVariables> TYPE = new SavedDataType<>("euru_worldvars", ctx -> new WorldVariables(), ctx -> CompoundTag.CODEC.xmap(tag -> {
			WorldVariables instance = new WorldVariables();
			instance.read(tag, ctx.levelOrThrow().registryAccess());
			return instance;
		}, instance -> instance.save(new CompoundTag(), ctx.levelOrThrow().registryAccess())));
		boolean _syncDirty = false;
		public ArrayList<Object> chunksloaded = new ArrayList<>();
		public double chunkloaderCounter = 0;

		public void read(CompoundTag nbt, HolderLookup.Provider lookupProvider) {
			chunksloaded = NbtArrayLists.loadGlobalWorld(nbt.getListOrEmpty("chunksloaded"), lookupProvider);
			chunkloaderCounter = nbt.getDoubleOr("chunkloaderCounter", 0);
		}

		public CompoundTag save(CompoundTag nbt, HolderLookup.Provider lookupProvider) {
			nbt.put("chunksloaded", NbtArrayLists.saveGlobalWorld(chunksloaded));
			nbt.putDouble("chunkloaderCounter", chunkloaderCounter);
			return nbt;
		}

		public void markSyncDirty() {
			this.setDirty();
			this._syncDirty = true;
		}

		static WorldVariables clientSide = new WorldVariables();

		public static WorldVariables get(LevelAccessor world) {
			if (world instanceof ServerLevel level) {
				return level.getDataStorage().computeIfAbsent(WorldVariables.TYPE);
			} else {
				return clientSide;
			}
		}
	}

	public static class MapVariables extends SavedData {
		public static final SavedDataType<MapVariables> TYPE = new SavedDataType<>("euru_mapvars", ctx -> new MapVariables(), ctx -> CompoundTag.CODEC.xmap(tag -> {
			MapVariables instance = new MapVariables();
			instance.read(tag, ctx.levelOrThrow().registryAccess());
			return instance;
		}, instance -> instance.save(new CompoundTag(), ctx.levelOrThrow().registryAccess())));
		boolean _syncDirty = false;

		public void read(CompoundTag nbt, HolderLookup.Provider lookupProvider) {
		}

		public CompoundTag save(CompoundTag nbt, HolderLookup.Provider lookupProvider) {
			return nbt;
		}

		public void markSyncDirty() {
			this.setDirty();
			this._syncDirty = true;
		}

		static MapVariables clientSide = new MapVariables();

		public static MapVariables get(LevelAccessor world) {
			if (world instanceof ServerLevelAccessor serverLevelAccessor) {
				return serverLevelAccessor.getLevel().getServer().getLevel(Level.OVERWORLD).getDataStorage().computeIfAbsent(MapVariables.TYPE);
			} else {
				return clientSide;
			}
		}
	}

	public record SavedDataSyncMessage(int dataType, SavedData data) implements CustomPacketPayload {
		public static final Type<SavedDataSyncMessage> TYPE = new Type<>(ResourceLocation.fromNamespaceAndPath(EuruMod.MODID, "saved_data_sync"));
		public static final StreamCodec<RegistryFriendlyByteBuf, SavedDataSyncMessage> STREAM_CODEC = StreamCodec.of((RegistryFriendlyByteBuf buffer, SavedDataSyncMessage message) -> {
			buffer.writeInt(message.dataType);
			if (message.data instanceof MapVariables mapVariables)
				buffer.writeNbt(mapVariables.save(new CompoundTag(), buffer.registryAccess()));
			else if (message.data instanceof WorldVariables worldVariables)
				buffer.writeNbt(worldVariables.save(new CompoundTag(), buffer.registryAccess()));
		}, (RegistryFriendlyByteBuf buffer) -> {
			int dataType = buffer.readInt();
			CompoundTag nbt = buffer.readNbt();
			SavedData data = null;
			if (nbt != null) {
				data = dataType == 0 ? new MapVariables() : new WorldVariables();
				if (data instanceof MapVariables mapVariables)
					mapVariables.read(nbt, buffer.registryAccess());
				else if (data instanceof WorldVariables worldVariables)
					worldVariables.read(nbt, buffer.registryAccess());
			}
			return new SavedDataSyncMessage(dataType, data);
		});

		@Override
		public Type<SavedDataSyncMessage> type() {
			return TYPE;
		}

		public static void handleData(final SavedDataSyncMessage message, final IPayloadContext context) {
			if (context.flow() == PacketFlow.CLIENTBOUND && message.data != null) {
				context.enqueueWork(() -> {
					if (message.dataType == 0)
						MapVariables.clientSide.read(((MapVariables) message.data).save(new CompoundTag(), context.player().registryAccess()), context.player().registryAccess());
					else
						WorldVariables.clientSide.read(((WorldVariables) message.data).save(new CompoundTag(), context.player().registryAccess()), context.player().registryAccess());
				}).exceptionally(e -> {
					context.connection().disconnect(Component.literal(e.getMessage()));
					return null;
				});
			}
		}
	}

	public static class PlayerVariables implements ValueIOSerializable {
		boolean _syncDirty = false;
		public double playerGP_Total = 0;
		public double playerGP_Used = 0;
		public double playerGPTickUpdateCounter = 0;
		public boolean playerGPChecking = false;
		public double playerGPUpdateTotal = 0;
		public double group_raw_solarpanels = 0;
		public double group_count_solarpanels = 0;
		public double playerGP_Used_Update = 0;
		public double group_cutoff_solarpanels = 0;
		public String playerAB1 = "\"\"";
		public String playerAB2 = "\"\"";
		public boolean changeAB = false;
		public double overlayCounter = 0;
		public double group_update_solarpanels = 0;
		public double group_efficiency_solarpanels = 0;
		public String changingAB1 = "\"\"";
		public String changingAB2 = "\"\"";
		public double playerGP_Total_SI = 0;
		public double playerGP_Used_SI = 0;
		public double randomGPCounter = 0;

		@Override
		public void serialize(ValueOutput output) {
			output.putDouble("playerGP_Total", playerGP_Total);
			output.putDouble("playerGP_Used", playerGP_Used);
			output.putDouble("playerGPTickUpdateCounter", playerGPTickUpdateCounter);
			output.putBoolean("playerGPChecking", playerGPChecking);
			output.putDouble("playerGPUpdateTotal", playerGPUpdateTotal);
			output.putDouble("group_raw_solarpanels", group_raw_solarpanels);
			output.putDouble("group_count_solarpanels", group_count_solarpanels);
			output.putDouble("playerGP_Used_Update", playerGP_Used_Update);
			output.putDouble("group_cutoff_solarpanels", group_cutoff_solarpanels);
			output.putString("playerAB1", playerAB1);
			output.putString("playerAB2", playerAB2);
			output.putBoolean("changeAB", changeAB);
			output.putDouble("overlayCounter", overlayCounter);
			output.putDouble("group_update_solarpanels", group_update_solarpanels);
			output.putDouble("group_efficiency_solarpanels", group_efficiency_solarpanels);
			output.putString("changingAB1", changingAB1);
			output.putString("changingAB2", changingAB2);
			output.putDouble("playerGP_Total_SI", playerGP_Total_SI);
			output.putDouble("playerGP_Used_SI", playerGP_Used_SI);
			output.putDouble("randomGPCounter", randomGPCounter);
		}

		@Override
		public void deserialize(ValueInput input) {
			playerGP_Total = input.getDoubleOr("playerGP_Total", 0);
			playerGP_Used = input.getDoubleOr("playerGP_Used", 0);
			playerGPTickUpdateCounter = input.getDoubleOr("playerGPTickUpdateCounter", 0);
			playerGPChecking = input.getBooleanOr("playerGPChecking", false);
			playerGPUpdateTotal = input.getDoubleOr("playerGPUpdateTotal", 0);
			group_raw_solarpanels = input.getDoubleOr("group_raw_solarpanels", 0);
			group_count_solarpanels = input.getDoubleOr("group_count_solarpanels", 0);
			playerGP_Used_Update = input.getDoubleOr("playerGP_Used_Update", 0);
			group_cutoff_solarpanels = input.getDoubleOr("group_cutoff_solarpanels", 0);
			playerAB1 = input.getStringOr("playerAB1", "");
			playerAB2 = input.getStringOr("playerAB2", "");
			changeAB = input.getBooleanOr("changeAB", false);
			overlayCounter = input.getDoubleOr("overlayCounter", 0);
			group_update_solarpanels = input.getDoubleOr("group_update_solarpanels", 0);
			group_efficiency_solarpanels = input.getDoubleOr("group_efficiency_solarpanels", 0);
			changingAB1 = input.getStringOr("changingAB1", "");
			changingAB2 = input.getStringOr("changingAB2", "");
			playerGP_Total_SI = input.getDoubleOr("playerGP_Total_SI", 0);
			playerGP_Used_SI = input.getDoubleOr("playerGP_Used_SI", 0);
			randomGPCounter = input.getDoubleOr("randomGPCounter", 0);
		}

		public void markSyncDirty() {
			_syncDirty = true;
		}
	}

	public record PlayerVariablesSyncMessage(PlayerVariables data, int player) implements CustomPacketPayload {
		public static final Type<PlayerVariablesSyncMessage> TYPE = new Type<>(ResourceLocation.fromNamespaceAndPath(EuruMod.MODID, "player_variables_sync"));
		public static final StreamCodec<RegistryFriendlyByteBuf, PlayerVariablesSyncMessage> STREAM_CODEC = StreamCodec.of((RegistryFriendlyByteBuf buffer, PlayerVariablesSyncMessage message) -> {
			TagValueOutput output = TagValueOutput.createWithoutContext(ProblemReporter.DISCARDING);
			message.data.serialize(output);
			buffer.writeInt(message.player());
			buffer.writeNbt(output.buildResult());
		}, (RegistryFriendlyByteBuf buffer) -> {
			PlayerVariablesSyncMessage message = new PlayerVariablesSyncMessage(new PlayerVariables(), buffer.readInt());
			message.data.deserialize(TagValueInput.create(ProblemReporter.DISCARDING, buffer.registryAccess(), buffer.readNbt()));
			return message;
		});

		@Override
		public Type<PlayerVariablesSyncMessage> type() {
			return TYPE;
		}

		public static void handleData(final PlayerVariablesSyncMessage message, final IPayloadContext context) {
			if (context.flow() == PacketFlow.CLIENTBOUND && message.data != null) {
				context.enqueueWork(() -> {
					Entity player = context.player().level().getEntity(message.player);
					if (player == null)
						return;
					TagValueOutput output = TagValueOutput.createWithContext(ProblemReporter.DISCARDING, context.player().registryAccess());
					message.data.serialize(output);
					player.getData(PLAYER_VARIABLES).deserialize(TagValueInput.create(ProblemReporter.DISCARDING, context.player().registryAccess(), output.buildResult()));
				}).exceptionally(e -> {
					context.connection().disconnect(Component.literal(e.getMessage()));
					return null;
				});
			}
		}
	}
}