package net.wavedk.extrautilitiesreutilized.jei_recipes;

import net.wavedk.extrautilitiesreutilized.procedures.ResonatorRecipeTypeValueProcedure;
import net.wavedk.extrautilitiesreutilized.init.EuruModJeiPlugin;
import net.wavedk.extrautilitiesreutilized.init.EuruModBlocks;

import net.minecraft.world.item.ItemStack;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.chat.Component;
import net.minecraft.core.NonNullList;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.Minecraft;

import mezz.jei.api.recipe.types.IRecipeType;
import mezz.jei.api.recipe.category.IRecipeCategory;
import mezz.jei.api.recipe.RecipeIngredientRole;
import mezz.jei.api.recipe.IFocusGroup;
import mezz.jei.api.helpers.IGuiHelper;
import mezz.jei.api.gui.ingredient.IRecipeSlotsView;
import mezz.jei.api.gui.drawable.IDrawable;
import mezz.jei.api.gui.builder.ITooltipBuilder;
import mezz.jei.api.gui.builder.IRecipeLayoutBuilder;
import mezz.jei.api.constants.VanillaTypes;

import java.util.stream.Collectors;
import java.util.List;
import java.util.Arrays;

public class ResonatorRecipeTypeRecipeCategory implements IRecipeCategory<ResonatorRecipeTypeRecipe> {
	public final static ResourceLocation UID = ResourceLocation.parse("euru:resonator_recipe_type");
	public final static ResourceLocation TEXTURE = ResourceLocation.parse("euru:textures/screens/resback-text.png");
	private final IDrawable background;
	private final IDrawable icon;

	private final Minecraft mc = Minecraft.getInstance();

	public ResonatorRecipeTypeRecipeCategory(IGuiHelper helper) {
		this.background = helper.createDrawable(TEXTURE, 0, 0, 179, 79);
		this.icon = helper.createDrawableIngredient(VanillaTypes.ITEM_STACK, new ItemStack(EuruModBlocks.RESONATOR.get().asItem()));
	}

	@Override
	public IRecipeType<ResonatorRecipeTypeRecipe> getRecipeType() {
		return EuruModJeiPlugin.ResonatorRecipeType_Type;
	}

	@Override
	public Component getTitle() {
		return Component.literal("Resonator");
	}

	@Override
	public IDrawable getIcon() {
		return this.icon;
	}

	@Override
	public int getWidth() {
		return this.background.getWidth();
	}

	@Override
	public int getHeight() {
		return this.background.getHeight();
	}

	@Override
	public void draw(ResonatorRecipeTypeRecipe recipe, IRecipeSlotsView recipeSlotsView, GuiGraphics guiGraphics, double mouseX, double mouseY) {
		this.background.draw(guiGraphics);

		guiGraphics.blit(RenderPipelines.GUI_TEXTURED, ResourceLocation.parse("euru:textures/screens/asprite.png"), 77, 27, 24 * ((mc.player.tickCount / 10) % 23) - 1, 0, 24, 24, 552, 24);

	}

	public void getTooltip(ITooltipBuilder tooltip, ResonatorRecipeTypeRecipe recipe, IRecipeSlotsView recipeSlotsView, double mouseX, double mouseY) {
		if (mouseX > 77 && mouseX < 101 && mouseY > 29 && mouseY < 53) {
			String hoverText = ResonatorRecipeTypeValueProcedure.execute(recipe.strings());
			if (hoverText != null) {
				tooltip.addAll(Arrays.stream(hoverText.split("\n")).map(Component::literal).collect(Collectors.toList()));
			}
		}
	}

	@Override
	public void setRecipe(IRecipeLayoutBuilder builder, ResonatorRecipeTypeRecipe recipe, IFocusGroup focuses) {
		List<ItemStack> recipeOutputs = recipe.getResultItems();
		List<ItemStack> actualOutputs = NonNullList.withSize(1, ItemStack.EMPTY);
		for (int i = 0; i < recipeOutputs.size(); i++) {
			actualOutputs.set(i, recipeOutputs.get(i));
		}
		builder.addSlot(RecipeIngredientRole.INPUT, 52, 31).add(recipe.getIngredients().get(0));
		builder.addSlot(RecipeIngredientRole.OUTPUT, 112, 31).add(actualOutputs.get(0));
	}
}