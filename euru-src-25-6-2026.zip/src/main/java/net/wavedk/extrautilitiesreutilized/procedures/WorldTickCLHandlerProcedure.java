package net.wavedk.extrautilitiesreutilized.procedures;

import org.checkerframework.checker.units.qual.s;
import org.checkerframework.checker.units.qual.A;

import org.apache.commons.lang3.function.FailableFunction;

import net.wavedk.extrautilitiesreutilized.network.EuruModVariables;
import net.wavedk.extrautilitiesreutilized.init.EuruModBlocks;

import net.neoforged.neoforge.event.tick.LevelTickEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.bus.api.Event;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.Vec2;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Entity;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.network.chat.Component;
import net.minecraft.core.BlockPos;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.CommandSource;

import javax.annotation.Nullable;

import java.util.function.Supplier;
import java.util.UUID;

@EventBusSubscriber
public class WorldTickCLHandlerProcedure {
	@SubscribeEvent
	public static void onWorldTick(LevelTickEvent.Post event) {
		execute(event, event.getLevel());
	}

	public static void execute(LevelAccessor world) {
		execute(null, world);
	}

	private static void execute(@Nullable Event event, LevelAccessor world) {
		Entity player = null;
		String uuidOfPlayer = "";
		String worldDimID = "";
		String x = "";
		String y = "";
		String z = "";
		boolean isBlock = false;
		if (EuruModVariables.WorldVariables.get(world).chunkloaderCounter > 10) {
			if (!EuruModVariables.WorldVariables.get(world).chunksloaded.isEmpty()) {
				for (Object arraylistiterator : EuruModVariables.WorldVariables.get(world).chunksloaded) {
					if (world instanceof ServerLevel _level)
						_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(0, 0, 0), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
								("say " + (arraylistiterator instanceof String _str2 ? _str2 : "")));
					uuidOfPlayer = ((arraylistiterator instanceof String _str5 ? _str5 : "").substring(0, (arraylistiterator instanceof String _str7 ? _str7 : "").indexOf(".", 0))).replace(".", "");
					if (world.getServer() != null) {
						LevelAccessor _origWorld = world;
						for (ServerLevel worlditerator : world.getServer().getAllLevels()) {
							world = worlditerator;
							player = world instanceof ServerLevel _serverGetEntityUUID ? _serverGetEntityUUID.getEntity(tryOrDefault(uuidOfPlayer, UUID::fromString, () -> new UUID(0, 0))) : null;
							if (player instanceof ServerPlayer || player instanceof Player) {
								break;
							}
						}
						world = _origWorld;
					}
					if (player instanceof ServerPlayer || player instanceof Player) {
						if (!(player.getData(EuruModVariables.PLAYER_VARIABLES).playerGPChecking && player.getData(EuruModVariables.PLAYER_VARIABLES).playerGP_Total < player.getData(EuruModVariables.PLAYER_VARIABLES).playerGP_Used)) {
							EuruModVariables.WorldVariables.get(world).chunkloaderCounter = 0;
							EuruModVariables.WorldVariables.get(world).markSyncDirty();
						}
						if (world instanceof ServerLevel _level)
							_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(0, 0, 0), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
									("say " + (arraylistiterator instanceof String _str16 ? _str16 : "")));
						if (world.getServer() != null) {
							LevelAccessor _origWorld = world;
							for (ServerLevel worlditerator : world.getServer().getAllLevels()) {
								world = worlditerator;
								worldDimID = (((arraylistiterator instanceof String _str19 ? _str19 : "").substring((arraylistiterator instanceof String _str21 ? _str21 : "").indexOf(".", 0),
										(arraylistiterator instanceof String _str23 ? _str23 : "").indexOf(",", 0))).replace(".", "")).replace(",", "");
								if ((world.getBlockState(BlockPos.containing(parseDouble(x), parseDouble(y), parseDouble(z)))).getBlock() == EuruModBlocks.CHUNK_LOADER.get()) {
									isBlock = true;
								}
							}
							world = _origWorld;
						}
						if (!(player.getData(EuruModVariables.PLAYER_VARIABLES).playerGPChecking && player.getData(EuruModVariables.PLAYER_VARIABLES).playerGP_Total < player.getData(EuruModVariables.PLAYER_VARIABLES).playerGP_Used) && isBlock) {
							if (world.getServer() != null) {
								LevelAccessor _origWorld = world;
								for (ServerLevel worlditerator : world.getServer().getAllLevels()) {
									world = worlditerator;
									worldDimID = (((arraylistiterator instanceof String _str28 ? _str28 : "").substring((arraylistiterator instanceof String _str30 ? _str30 : "").indexOf(".", 0),
											(arraylistiterator instanceof String _str32 ? _str32 : "").indexOf(",", 0))).replace(".", "")).replace(",", "");
									if ((worldDimID).equals("" + (world instanceof Level _lvl ? _lvl.dimension() : (world instanceof WorldGenLevel _wgl ? _wgl.getLevel().dimension() : Level.OVERWORLD)))) {
										if (world instanceof ServerLevel _level)
											_level.getServer().getCommands().performPrefixedCommand(
													new CommandSourceStack(CommandSource.NULL, new Vec3(0, 0, 0), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
													((((("forceload add " + ((arraylistiterator instanceof String _str35 ? _str35 : "").substring((arraylistiterator instanceof String _str37 ? _str37 : "").indexOf(",", 0)))).replace(",", ""))
															.replace(".", "")).replace("_", "")).replace("-", "")));
									}
								}
								world = _origWorld;
							}
						} else {
							if (world.getServer() != null) {
								LevelAccessor _origWorld = world;
								for (ServerLevel worlditerator : world.getServer().getAllLevels()) {
									world = worlditerator;
									worldDimID = (((arraylistiterator instanceof String _str41 ? _str41 : "").substring((arraylistiterator instanceof String _str43 ? _str43 : "").indexOf(".", 0),
											(arraylistiterator instanceof String _str45 ? _str45 : "").indexOf(",", 0))).replace(".", "")).replace(",", "");
									if ((worldDimID).equals("" + (world instanceof Level _lvl ? _lvl.dimension() : (world instanceof WorldGenLevel _wgl ? _wgl.getLevel().dimension() : Level.OVERWORLD)))) {
										if (world instanceof ServerLevel _level)
											_level.getServer().getCommands().performPrefixedCommand(
													new CommandSourceStack(CommandSource.NULL, new Vec3(0, 0, 0), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
													((((("forceload remove" + ((arraylistiterator instanceof String _str48 ? _str48 : "").substring((arraylistiterator instanceof String _str50 ? _str50 : "").indexOf(",", 0)))).replace(",", ""))
															.replace(".", "")).replace("_", "")).replace("-", "")));
									}
								}
								world = _origWorld;
							}
							EuruModVariables.WorldVariables.get(world).chunksloaded.remove((int) EuruModVariables.WorldVariables.get(world).chunksloaded.indexOf(arraylistiterator));
						}
					}
				}
			}
		} else {
			EuruModVariables.WorldVariables.get(world).chunkloaderCounter = EuruModVariables.WorldVariables.get(world).chunkloaderCounter + 1;
			EuruModVariables.WorldVariables.get(world).markSyncDirty();
		}
	}

	private static <A, B> A tryOrDefault(B funcArg, FailableFunction<B, A, Exception> func, Supplier<A> fallback) {
		try {
			return func.apply(funcArg);
		} catch (Exception e) {
			return fallback.get();
		}
	}

	private static double parseDouble(String s) {
		try {
			return Double.parseDouble(s.trim());
		} catch (Exception e) {
			return 0;
		}
	}
}