package net.wavedk.extrautilitiesreutilized.procedures;

import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.core.BlockPos;

public class ReturnEnchanterErrrorProcedure {
	public static String execute(LevelAccessor world, double x, double y, double z) {
		if ((getBlockNBTString(world, BlockPos.containing(x, y, z), "errorMessage")).equals("notEnoughFE")) {
			return "Not enough FE available! (requires " + getBlockNBTNumber(world, BlockPos.containing(x, y, z), "fe_required") + "FE)";
		} else if ((getBlockNBTString(world, BlockPos.containing(x, y, z), "errorMessage")).equals("tmGP")) {
			return "Not enough Grid Power available!";
		} else if ((getBlockNBTString(world, BlockPos.containing(x, y, z), "errorMessage")).equals("notEnoughLapis")) {
			return "Not enough Lapis available! (requires " + getBlockNBTNumber(world, BlockPos.containing(x, y, z), "lapis_required") + " lapis lazuli)";
		} else if ((getBlockNBTString(world, BlockPos.containing(x, y, z), "errorMessage")).equals("outputFilled")) {
			return "The output slot is filled!";
		}
		return "";
	}

	private static String getBlockNBTString(LevelAccessor world, BlockPos pos, String tag) {
		BlockEntity blockEntity = world.getBlockEntity(pos);
		if (blockEntity != null)
			return blockEntity.getPersistentData().getStringOr(tag, "");
		return "";
	}

	private static double getBlockNBTNumber(LevelAccessor world, BlockPos pos, String tag) {
		BlockEntity blockEntity = world.getBlockEntity(pos);
		if (blockEntity != null)
			return blockEntity.getPersistentData().getDoubleOr(tag, 0);
		return -1;
	}
}