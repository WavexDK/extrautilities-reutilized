package net.wavedk.extrautilitiesreutilized.procedures;

import org.checkerframework.checker.units.qual.A;

import org.apache.commons.lang3.function.FailableFunction;

import net.wavedk.extrautilitiesreutilized.network.EuruModVariables;
import net.wavedk.extrautilitiesreutilized.init.EuruModItems;
import net.wavedk.extrautilitiesreutilized.block.entity.EnchanterBlockEntity;

import net.neoforged.neoforge.items.IItemHandlerModifiable;
import net.neoforged.neoforge.items.IItemHandler;
import net.neoforged.neoforge.energy.IEnergyStorage;
import net.neoforged.neoforge.common.extensions.ILevelExtension;
import net.neoforged.neoforge.capabilities.Capabilities;
import net.neoforged.fml.loading.FMLPaths;

import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Entity;
import net.minecraft.tags.ItemTags;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.Direction;
import net.minecraft.core.BlockPos;

import java.util.function.Supplier;
import java.util.UUID;

import java.io.IOException;
import java.io.FileReader;
import java.io.File;
import java.io.BufferedReader;

public class EnchanterOnTickUpdateProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z) {
		File recipeList = new File("");
		File configFile = new File("");
		Entity player = null;
		com.google.gson.JsonArray rlArray = new com.google.gson.JsonArray();
		com.google.gson.JsonObject configOBJ = new com.google.gson.JsonObject();
		com.google.gson.JsonObject catOBJ = new com.google.gson.JsonObject();
		com.google.gson.JsonObject blockOBJ = new com.google.gson.JsonObject();
		com.google.gson.JsonObject recipeOBJ = new com.google.gson.JsonObject();
		String rl_cItem = "";
		double mult = 0;
		double cost = 0;
		double rlNum = 0;
		double feStep = 0;
		double energyRemove = 0;
		boolean canPass = false;
		boolean on = false;
		if (world.getServer() != null) {
			LevelAccessor _origWorld = world;
			for (ServerLevel worlditerator : world.getServer().getAllLevels()) {
				world = worlditerator;
				if (!(player instanceof Player || player instanceof ServerPlayer)) {
					player = world instanceof ServerLevel _serverGetEntityUUID ? _serverGetEntityUUID.getEntity(tryOrDefault((getBlockNBTString(world, BlockPos.containing(x, y, z), "placedBy")), UUID::fromString, () -> new UUID(0, 0))) : null;
					if (player instanceof Player || player instanceof ServerPlayer) {
						break;
					}
				}
			}
			world = _origWorld;
		}
		if (player instanceof Player || player instanceof ServerPlayer) {// redstoneMode
			if (getBlockNBTNumber(world, BlockPos.containing(x, y, z), "redstoneMode") == 0) {
				setBlockNBTLogic(world, x, y, z, "redstoneModeOn", true);
			} else if (getBlockNBTNumber(world, BlockPos.containing(x, y, z), "redstoneMode") == 1) {
				if (world instanceof Level _level13 && _level13.hasNeighborSignal(BlockPos.containing(x, y, z))) {
					setBlockNBTLogic(world, x, y, z, "redstoneModeOn", true);
				} else {
					setBlockNBTLogic(world, x, y, z, "redstoneModeOn", false);
				}
			} else if (getBlockNBTNumber(world, BlockPos.containing(x, y, z), "redstoneMode") == 2) {
				if (world instanceof Level _level17 && _level17.hasNeighborSignal(BlockPos.containing(x, y, z))) {
					setBlockNBTLogic(world, x, y, z, "redstoneModeOn", false);
				} else {
					setBlockNBTLogic(world, x, y, z, "redstoneModeOn", true);
				}
			} else if (getBlockNBTNumber(world, BlockPos.containing(x, y, z), "redstoneMode") == 3) {
				setBlockNBTLogic(world, x, y, z, "redstoneModeOn", false);
			} else {
				setBlockNBTLogic(world, x, y, z, "redstoneModeOn", true);
			}
			if (getBlockNBTLogic(world, BlockPos.containing(x, y, z), "redstoneModeOn")) {// multCalc
				mult = 1;
				if ((itemFromBlockInventory(world, BlockPos.containing(x, y, z), 3).copy()).getItem() == EuruModItems.SPEED_UPGRADE.get()) {
					mult = 1 + itemFromBlockInventory(world, BlockPos.containing(x, y, z), 3).getCount() / 4d;
					cost = itemFromBlockInventory(world, BlockPos.containing(x, y, z), 3).getCount();
				} else if ((itemFromBlockInventory(world, BlockPos.containing(x, y, z), 3).copy()).getItem() == EuruModItems.MAGICAL_SPEED_UPGRADE.get()) {
					mult = 1 + itemFromBlockInventory(world, BlockPos.containing(x, y, z), 3).getCount() / 2d;
					cost = itemFromBlockInventory(world, BlockPos.containing(x, y, z), 3).getCount();
				} // getItem
				on = false;
				if (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 0).getCount() > 0) {
					if ((getBlockNBTString(world, BlockPos.containing(x, y, z), "output")).equals("") || (getBlockNBTString(world, BlockPos.containing(x, y, z), "cItem")).equals("")
							|| getBlockNBTNumber(world, BlockPos.containing(x, y, z), "wait_time") == 0 || getBlockNBTNumber(world, BlockPos.containing(x, y, z), "lapis_required") == 0
							|| getBlockNBTNumber(world, BlockPos.containing(x, y, z), "fe_required") == 0 || getBlockNBTNumber(world, BlockPos.containing(x, y, z), "gp_required") == 0) {
						configFile = new File((FMLPaths.GAMEDIR.get().toString() + "/config/euru/"), File.separator + "euru_unified_config.json");// readConfig
						{
							try {
								BufferedReader bufferedReader = new BufferedReader(new FileReader(configFile));
								StringBuilder jsonstringbuilder = new StringBuilder();
								String line;
								while ((line = bufferedReader.readLine()) != null) {
									jsonstringbuilder.append(line);
								}
								bufferedReader.close();
								configOBJ = new com.google.gson.Gson().fromJson(jsonstringbuilder.toString(), com.google.gson.JsonObject.class);
								// getOBJs
								catOBJ = configOBJ.get("recipes").getAsJsonObject();
								blockOBJ = catOBJ.get((BuiltInRegistries.BLOCK.getKey((world.getBlockState(BlockPos.containing(x, y, z))).getBlock()).toString())).getAsJsonObject();
								rlArray = blockOBJ.get("recipeList").getAsJsonArray();// loopRL
								rlNum = 0;
								for (int index0 = 0; index0 < (int) rlArray.size(); index0++) {
									rl_cItem = rlArray.get((int) rlNum).getAsString();
									if ((BuiltInRegistries.ITEM.getKey((itemFromBlockInventory(world, BlockPos.containing(x, y, z), 0).copy()).getItem()).toString()).equals(rl_cItem)
											|| (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 0).copy()).is(ItemTags.create(ResourceLocation.parse((rl_cItem).toLowerCase(java.util.Locale.ENGLISH))))) {// foundItem-SettingNBT
										recipeOBJ = blockOBJ.get(rl_cItem).getAsJsonObject();
										setBlockNBTText(world, x, y, z, "output", recipeOBJ.get("output").getAsString());
										setBlockNBTText(world, x, y, z, "cItem", rl_cItem);
										setBlockNBTNumber(world, x, y, z, "gp_required", recipeOBJ.get("gp_required").getAsDouble());
										setBlockNBTNumber(world, x, y, z, "wait_time", recipeOBJ.get("wait_time").getAsDouble());
										setBlockNBTNumber(world, x, y, z, "lapis_required", recipeOBJ.get("lapis_required").getAsDouble());
										setBlockNBTNumber(world, x, y, z, "fe_required", recipeOBJ.get("fe_required").getAsDouble());
										break;
									}
									rlNum = rlNum + 1;
								}
							} catch (IOException e) {
								e.printStackTrace();
							}
						}
					}
					if (!(getBlockNBTString(world, BlockPos.containing(x, y, z), "output")).equals("") && !(getBlockNBTString(world, BlockPos.containing(x, y, z), "cItem")).equals("")
							&& getBlockNBTNumber(world, BlockPos.containing(x, y, z), "wait_time") != 0 && getBlockNBTNumber(world, BlockPos.containing(x, y, z), "lapis_required") != 0
							&& getBlockNBTNumber(world, BlockPos.containing(x, y, z), "fe_required") != 0 && getBlockNBTNumber(world, BlockPos.containing(x, y, z), "gp_required") != 0) {
						if ((itemFromBlockInventory(world, BlockPos.containing(x, y, z), 0).copy()).is(ItemTags.create(ResourceLocation.parse(((getBlockNBTString(world, BlockPos.containing(x, y, z), "cItem"))).toLowerCase(java.util.Locale.ENGLISH))))
								|| (BuiltInRegistries.ITEM.getKey((itemFromBlockInventory(world, BlockPos.containing(x, y, z), 0).copy()).getItem()).toString()).equals(getBlockNBTString(world, BlockPos.containing(x, y, z), "cItem"))) {
							if (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 2).getCount() == 0
									|| itemFromBlockInventory(world, BlockPos.containing(x, y, z), 2).getCount() < (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 2).copy()).getMaxStackSize()
											&& (BuiltInRegistries.ITEM.getKey((itemFromBlockInventory(world, BlockPos.containing(x, y, z), 2).copy()).getItem()).toString()).equals(getBlockNBTString(world, BlockPos.containing(x, y, z), "output"))) {
								if ((itemFromBlockInventory(world, BlockPos.containing(x, y, z), 1).copy()).getItem() == Items.LAPIS_LAZULI
										&& itemFromBlockInventory(world, BlockPos.containing(x, y, z), 1).getCount() >= getBlockNBTNumber(world, BlockPos.containing(x, y, z), "lapis_required")) {
									if (player.getData(EuruModVariables.PLAYER_VARIABLES).playerGPChecking) {
										{
											EuruModVariables.PlayerVariables _vars = player.getData(EuruModVariables.PLAYER_VARIABLES);
											_vars.playerGP_Used_Update = player.getData(EuruModVariables.PLAYER_VARIABLES).playerGP_Used_Update + getBlockNBTNumber(world, BlockPos.containing(x, y, z), "gp_required") + cost;
											_vars.markSyncDirty();
										}
									}
									if (player.getData(EuruModVariables.PLAYER_VARIABLES).playerGP_Total >= player.getData(EuruModVariables.PLAYER_VARIABLES).playerGP_Used) {
										feStep = getBlockNBTNumber(world, BlockPos.containing(x, y, z), "fe_required") / getBlockNBTNumber(world, BlockPos.containing(x, y, z), "wait_time");
										if (getBlockNBTNumber(world, BlockPos.containing(x, y, z), "cProgress") == 0) {
											if (getEnergyStored(world, BlockPos.containing(x, y, z), null) >= getBlockNBTNumber(world, BlockPos.containing(x, y, z), "fe_required")) {
												setBlockNBTNumber(world, x, y, z, "cProgress", (getBlockNBTNumber(world, BlockPos.containing(x, y, z), "cProgress") + 1 * mult));
												energyRemove = feStep * mult;
												on = true;
												if (world.getBlockEntity(new BlockPos((int) x, (int) y, (int) z)) instanceof EnchanterBlockEntity be) {
													be.removeEnergy((int) energyRemove);
												}
												setBlockNBTText(world, x, y, z, "errorMessage", "");
											} else {
												setBlockNBTText(world, x, y, z, "errorMessage", "notEnoughFE");
											}
										} else if (getBlockNBTNumber(world, BlockPos.containing(x, y, z), "cProgress") < getBlockNBTNumber(world, BlockPos.containing(x, y, z), "wait_time")) {
											if (getEnergyStored(world, BlockPos.containing(x, y, z), null) >= getBlockNBTNumber(world, BlockPos.containing(x, y, z), "fe_required")
													- feStep * getBlockNBTNumber(world, BlockPos.containing(x, y, z), "cProgress")) {
												setBlockNBTNumber(world, x, y, z, "cProgress", (getBlockNBTNumber(world, BlockPos.containing(x, y, z), "cProgress") + 1 * mult));
												on = true;
												energyRemove = feStep * mult;
												if (world.getBlockEntity(new BlockPos((int) x, (int) y, (int) z)) instanceof EnchanterBlockEntity be) {
													be.removeEnergy((int) energyRemove);
												}
												setBlockNBTText(world, x, y, z, "errorMessage", "");
											} else {
												setBlockNBTText(world, x, y, z, "errorMessage", "notEnoughFE");
											}
										} else {
											if (world instanceof ILevelExtension _ext && _ext.getCapability(Capabilities.ItemHandler.BLOCK, BlockPos.containing(x, y, z), null) instanceof IItemHandlerModifiable _itemHandlerModifiable) {
												ItemStack _setstack = new ItemStack(BuiltInRegistries.ITEM.getValue(ResourceLocation.parse(((getBlockNBTString(world, BlockPos.containing(x, y, z), "output"))).toLowerCase(java.util.Locale.ENGLISH))))
														.copy();
												_setstack.setCount(itemFromBlockInventory(world, BlockPos.containing(x, y, z), 2).getCount() + 1);
												_itemHandlerModifiable.setStackInSlot(2, _setstack);
											}
											if (world instanceof ILevelExtension _ext && _ext.getCapability(Capabilities.ItemHandler.BLOCK, BlockPos.containing(x, y, z), null) instanceof IItemHandlerModifiable _itemHandlerModifiable) {
												ItemStack _setstack = new ItemStack(Items.LAPIS_LAZULI).copy();
												_setstack.setCount((int) (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 1).getCount() - getBlockNBTNumber(world, BlockPos.containing(x, y, z), "lapis_required")));
												_itemHandlerModifiable.setStackInSlot(1, _setstack);
											}
											if (world instanceof ILevelExtension _ext && _ext.getCapability(Capabilities.ItemHandler.BLOCK, BlockPos.containing(x, y, z), null) instanceof IItemHandlerModifiable _itemHandlerModifiable) {
												ItemStack _setstack = (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 0).copy()).copy();
												_setstack.setCount(itemFromBlockInventory(world, BlockPos.containing(x, y, z), 0).getCount() - 1);
												_itemHandlerModifiable.setStackInSlot(0, _setstack);
											}
											setBlockNBTNumber(world, x, y, z, "cProgress", 0);
											setBlockNBTText(world, x, y, z, "output", "");
										}
									} else {
										setBlockNBTText(world, x, y, z, "errorMessage", "tmGP");
									}
								} else {
									setBlockNBTText(world, x, y, z, "output", "");
									setBlockNBTText(world, x, y, z, "errorMessage", "notEnoughLapis");
								}
							} else {
								setBlockNBTText(world, x, y, z, "output", "");
								setBlockNBTText(world, x, y, z, "errorMessage", "outputFilled");
							}
						} else {
							setBlockNBTText(world, x, y, z, "output", "");
							setBlockNBTText(world, x, y, z, "errorMessage", "noInput");
						}
						if (!(getBlockNBTString(world, BlockPos.containing(x, y, z), "errorMessage")).equals("") && !(getBlockNBTString(world, BlockPos.containing(x, y, z), "errorMessage")).equals("notEnoughFE")) {
							setBlockNBTNumber(world, x, y, z, "cProgress", 0);
						}
					}
				} else {
					setBlockNBTNumber(world, x, y, z, "cProgress", 0);
					setBlockNBTText(world, x, y, z, "output", "");
					setBlockNBTText(world, x, y, z, "errorMessage", "noInput");
				}
				if (!on) {
					if (3 < getBlockNBTNumber(world, BlockPos.containing(x, y, z), "onCounter")) {
						setBlockNBTNumber(world, x, y, z, "onCounter", 0);
						setBooleanBlockState(world, x, y, z, "on", on);
					} else {
						setBlockNBTNumber(world, x, y, z, "onCounter", (1 + getBlockNBTNumber(world, BlockPos.containing(x, y, z), "onCounter")));
					}
				} else {
					setBooleanBlockState(world, x, y, z, "on", true);
					setBlockNBTNumber(world, x, y, z, "onCounter", 0);
				}
			}
		}
	}

	private static String getBlockNBTString(LevelAccessor world, BlockPos pos, String tag) {
		BlockEntity blockEntity = world.getBlockEntity(pos);
		if (blockEntity != null)
			return blockEntity.getPersistentData().getStringOr(tag, "");
		return "";
	}

	private static <A, B> A tryOrDefault(B funcArg, FailableFunction<B, A, Exception> func, Supplier<A> fallback) {
		try {
			return func.apply(funcArg);
		} catch (Exception e) {
			return fallback.get();
		}
	}

	private static double getBlockNBTNumber(LevelAccessor world, BlockPos pos, String tag) {
		BlockEntity blockEntity = world.getBlockEntity(pos);
		if (blockEntity != null)
			return blockEntity.getPersistentData().getDoubleOr(tag, 0);
		return -1;
	}

	private static void setBlockNBTLogic(LevelAccessor world, double x, double y, double z, String tag, boolean value) {
		if (!world.isClientSide()) {
			BlockPos pos = BlockPos.containing(x, y, z);
			BlockEntity blockEntity = world.getBlockEntity(pos);
			BlockState blockState = world.getBlockState(pos);
			if (blockEntity != null) {
				blockEntity.getPersistentData().putBoolean(tag, value);
			}
			if (world instanceof Level level) {
				level.sendBlockUpdated(pos, blockState, blockState, 3);
			}
		}
	}

	private static boolean getBlockNBTLogic(LevelAccessor world, BlockPos pos, String tag) {
		BlockEntity blockEntity = world.getBlockEntity(pos);
		if (blockEntity != null)
			return blockEntity.getPersistentData().getBooleanOr(tag, false);
		return false;
	}

	private static ItemStack itemFromBlockInventory(LevelAccessor world, BlockPos pos, int slot) {
		if (world instanceof ILevelExtension ext) {
			IItemHandler itemHandler = ext.getCapability(Capabilities.ItemHandler.BLOCK, pos, null);
			if (itemHandler != null)
				return itemHandler.getStackInSlot(slot);
		}
		return ItemStack.EMPTY;
	}

	private static void setBlockNBTText(LevelAccessor world, double x, double y, double z, String tag, String value) {
		if (!world.isClientSide()) {
			BlockPos pos = BlockPos.containing(x, y, z);
			BlockEntity blockEntity = world.getBlockEntity(pos);
			BlockState blockState = world.getBlockState(pos);
			if (blockEntity != null) {
				blockEntity.getPersistentData().putString(tag, value);
			}
			if (world instanceof Level level) {
				level.sendBlockUpdated(pos, blockState, blockState, 3);
			}
		}
	}

	private static void setBlockNBTNumber(LevelAccessor world, double x, double y, double z, String tag, double value) {
		if (!world.isClientSide()) {
			BlockPos pos = BlockPos.containing(x, y, z);
			BlockEntity blockEntity = world.getBlockEntity(pos);
			BlockState blockState = world.getBlockState(pos);
			if (blockEntity != null) {
				blockEntity.getPersistentData().putDouble(tag, value);
			}
			if (world instanceof Level level) {
				level.sendBlockUpdated(pos, blockState, blockState, 3);
			}
		}
	}

	public static int getEnergyStored(LevelAccessor level, BlockPos pos, Direction direction) {
		if (level instanceof ILevelExtension levelExtension) {
			IEnergyStorage energyStorage = levelExtension.getCapability(Capabilities.EnergyStorage.BLOCK, pos, direction);
			if (energyStorage != null)
				return energyStorage.getEnergyStored();
		}
		return 0;
	}

	private static void setBooleanBlockState(LevelAccessor world, double x, double y, double z, String property, boolean value) {
		BlockPos pos = BlockPos.containing(x, y, z);
		BlockState state = world.getBlockState(pos);
		if (state.getBlock().getStateDefinition().getProperty(property) instanceof BooleanProperty booleanProperty) {
			world.setBlock(pos, state.setValue(booleanProperty, value), 3);
		}
	}
}