package net.wavedk.extrautilitiesreutilized.procedures;

import net.wavedk.extrautilitiesreutilized.network.EuruModVariables;
import net.wavedk.extrautilitiesreutilized.init.EuruModItems;
import net.wavedk.extrautilitiesreutilized.EuruMod;

import net.neoforged.neoforge.items.IItemHandler;
import net.neoforged.neoforge.event.tick.PlayerTickEvent;
import net.neoforged.fml.loading.FMLPaths;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.bus.api.Event;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.GameType;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Entity;
import net.minecraft.core.registries.BuiltInRegistries;

import javax.annotation.Nullable;

import java.io.IOException;
import java.io.FileReader;
import java.io.File;
import java.io.BufferedReader;

@EventBusSubscriber
public class PlayerGPTickUpdateProcedure {
	@SubscribeEvent
	public static void onPlayerTick(PlayerTickEvent.Post event) {
		execute(event, event.getEntity().level(), event.getEntity());
	}

	public static void execute(LevelAccessor world, Entity entity) {
		execute(null, world, entity);
	}

	private static void execute(@Nullable Event event, LevelAccessor world, Entity entity) {
		if (entity == null)
			return;
		double solarPanelCutOff = 0;
		com.google.gson.JsonObject cObj = new com.google.gson.JsonObject();
		com.google.gson.JsonObject catobj = new com.google.gson.JsonObject();
		com.google.gson.JsonObject obj = new com.google.gson.JsonObject();
		File cfile = new File("");
		boolean isEquippedCurios = false;
		if (entity.getData(EuruModVariables.PLAYER_VARIABLES).playerGPTickUpdateCounter < 5) {
			{
				EuruModVariables.PlayerVariables _vars = entity.getData(EuruModVariables.PLAYER_VARIABLES);
				_vars.playerGPTickUpdateCounter = entity.getData(EuruModVariables.PLAYER_VARIABLES).playerGPTickUpdateCounter + 1;
				_vars.markSyncDirty();
			}
			GPOverlayTickProcedure.execute(world, entity);
		} else {
			if (entity.getData(EuruModVariables.PLAYER_VARIABLES).playerGPChecking == false) {
				{
					EuruModVariables.PlayerVariables _vars = entity.getData(EuruModVariables.PLAYER_VARIABLES);
					_vars.playerGPChecking = true;
					_vars.markSyncDirty();
				}
				GPOverlayTickProcedure.execute(world, entity);
				{
					EuruModVariables.PlayerVariables _vars = entity.getData(EuruModVariables.PLAYER_VARIABLES);
					_vars.group_raw_solarpanels = 0;
					_vars.group_count_solarpanels = 0;
					_vars.group_raw_mills = 0;
					_vars.group_count_mills = 0;
					_vars.markSyncDirty();
				}
			} else {
				{
					EuruModVariables.PlayerVariables _vars = entity.getData(EuruModVariables.PLAYER_VARIABLES);
					_vars.playerGP_Used = entity.getData(EuruModVariables.PLAYER_VARIABLES).playerGP_Used_Update;
					_vars.playerGP_Used_Update = 0;
					_vars.playerGPChecking = false;
					_vars.playerGPTickUpdateCounter = 1;
					_vars.playerGPUpdateTotal = 0;
					_vars.markSyncDirty();
				}
				UpdategroupmillProcedure.execute(entity);
				UpdategroupsolarpanelsProcedure.execute(entity);
				{
					EuruModVariables.PlayerVariables _vars = entity.getData(EuruModVariables.PLAYER_VARIABLES);
					_vars.playerGP_Total = entity.getData(EuruModVariables.PLAYER_VARIABLES).playerGPUpdateTotal;
					_vars.markSyncDirty();
				}
				GPOverlayTickProcedure.execute(world, entity);
			}
		}
		if (entity instanceof Player player2) {
			IItemHandler inventory2 = EuruMod.CuriosApiHelper.getCuriosInventory(player2);
			if (inventory2 != null) {
				for (int i = 0; i < inventory2.getSlots(); i++) {
					ItemStack itemstackiterator = inventory2.getStackInSlot(i);
					if (itemstackiterator.getItem() == EuruModItems.ANGEL_RING.get()) {
						isEquippedCurios = true;
						break;
					}
				}
			}
		}
		if (!(entity instanceof Player _plr3 && _plr3.gameMode() == GameType.SPECTATOR || entity instanceof Player _plr4 && _plr4.gameMode() == GameType.CREATIVE)) {
			entity.getPersistentData().putBoolean("isCFlying", false);
			if (entity instanceof Player _player) {
				_player.getAbilities().mayfly = ((hasEntityInInventory(entity, new ItemStack(EuruModItems.ANGEL_RING.get())) || isEquippedCurios)
						&& entity.getData(EuruModVariables.PLAYER_VARIABLES).playerGP_Total >= entity.getData(EuruModVariables.PLAYER_VARIABLES).playerGP_Used);
				_player.onUpdateAbilities();
			}
		} else if (!entity.getPersistentData().getBooleanOr("isCFlying", false)) {
			entity.getPersistentData().putBoolean("isCFlying", true);
			if (entity instanceof Player _player) {
				_player.getAbilities().mayfly = true;
				_player.onUpdateAbilities();
			}
		}
		if ((hasEntityInInventory(entity, new ItemStack(EuruModItems.ANGEL_RING.get())) || isEquippedCurios) && entity.getData(EuruModVariables.PLAYER_VARIABLES).playerGPChecking && entity instanceof Player _plr12
				&& _plr12.gameMode() == GameType.SURVIVAL) {
			cfile = new File((FMLPaths.GAMEDIR.get().toString() + "/config/euru/"), File.separator + "euru_unified_config.json");
			{
				try {
					BufferedReader bufferedReader = new BufferedReader(new FileReader(cfile));
					StringBuilder jsonstringbuilder = new StringBuilder();
					String line;
					while ((line = bufferedReader.readLine()) != null) {
						jsonstringbuilder.append(line);
					}
					bufferedReader.close();
					obj = new com.google.gson.Gson().fromJson(jsonstringbuilder.toString(), com.google.gson.JsonObject.class);
					catobj = obj.get("general").getAsJsonObject();
					cObj = catobj.get((BuiltInRegistries.ITEM.getKey(EuruModItems.ANGEL_RING.get()).toString())).getAsJsonObject();
					{
						EuruModVariables.PlayerVariables _vars = entity.getData(EuruModVariables.PLAYER_VARIABLES);
						_vars.playerGP_Used_Update = entity.getData(EuruModVariables.PLAYER_VARIABLES).playerGP_Used_Update + cObj.get("gp_needed").getAsDouble();
						_vars.markSyncDirty();
					}
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		{
			EuruModVariables.PlayerVariables _vars = entity.getData(EuruModVariables.PLAYER_VARIABLES);
			_vars.updateAB1 = true;
			_vars.updateab2 = true;
			_vars.markSyncDirty();
		}
	}

	private static boolean hasEntityInInventory(Entity entity, ItemStack itemstack) {
		if (entity instanceof Player player)
			return player.getInventory().contains(stack -> !stack.isEmpty() && ItemStack.isSameItem(stack, itemstack));
		return false;
	}
}