package net.wavedk.extrautilitiesreutilized.block;

import net.wavedk.extrautilitiesreutilized.init.EuruModBlocks;

import net.minecraft.world.level.block.state.properties.NoteBlockInstrument;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.component.TooltipDisplay;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;
import net.minecraft.network.chat.Component;

import java.util.function.Consumer;

public class TripleCompressedCobblestoneBlock extends Block {
	public TripleCompressedCobblestoneBlock(BlockBehaviour.Properties properties) {
		super(properties.strength(16f, 48f).requiresCorrectToolForDrops().instrument(NoteBlockInstrument.BASEDRUM));
	}

	public static class Item extends BlockItem {
		public Item(Item.Properties properties) {
			super(EuruModBlocks.TRIPLE_COMPRESSED_COBBLESTONE.get(), properties);
		}

		@Override
		public void appendHoverText(ItemStack itemstack, Item.TooltipContext context, TooltipDisplay tooltipDisplay, Consumer<Component> componentConsumer, TooltipFlag flag) {
			super.appendHoverText(itemstack, context, tooltipDisplay, componentConsumer, flag);
			componentConsumer.accept(Component.translatable("block.euru.triple_compressed_cobblestone.description_0"));
		}
	}
}