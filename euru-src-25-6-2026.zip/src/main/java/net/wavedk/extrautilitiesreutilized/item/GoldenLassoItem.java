package net.wavedk.extrautilitiesreutilized.item;

import net.wavedk.extrautilitiesreutilized.procedures.GoldenLassoSpecialInformationProcedure;
import net.wavedk.extrautilitiesreutilized.procedures.GoldenLassoPropertyValueProviderProcedure;
import net.wavedk.extrautilitiesreutilized.EuruMod;

import net.minecraft.world.item.component.TooltipDisplay;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.network.chat.Component;
import net.minecraft.client.renderer.item.properties.numeric.RangeSelectItemModelProperty;
import net.minecraft.client.multiplayer.ClientLevel;

import javax.annotation.Nullable;

import java.util.function.Consumer;

import com.mojang.serialization.MapCodec;

public class GoldenLassoItem extends Item {
	public GoldenLassoItem(Item.Properties properties) {
		super(properties.stacksTo(1));
	}

	@Override
	public void appendHoverText(ItemStack itemstack, Item.TooltipContext context, TooltipDisplay tooltipDisplay, Consumer<Component> componentConsumer, TooltipFlag flag) {
		super.appendHoverText(itemstack, context, tooltipDisplay, componentConsumer, flag);
		Entity entity = itemstack.getEntityRepresentation() != null ? itemstack.getEntityRepresentation() : EuruMod.clientPlayer();
		String hoverText = GoldenLassoSpecialInformationProcedure.execute(itemstack);
		if (hoverText != null) {
			for (String line : hoverText.split("\n")) {
				componentConsumer.accept(Component.literal(line));
			}
		}
	}

	public record FullProperty() implements RangeSelectItemModelProperty {
		public static final MapCodec<FullProperty> MAP_CODEC = MapCodec.unit(new FullProperty());

		@Override
		public float get(ItemStack itemStackToRender, @Nullable ClientLevel clientWorld, @Nullable LivingEntity entity, int seed) {
			return (float) GoldenLassoPropertyValueProviderProcedure.execute(itemStackToRender);
		}

		@Override
		public MapCodec<FullProperty> type() {
			return MAP_CODEC;
		}
	}
}