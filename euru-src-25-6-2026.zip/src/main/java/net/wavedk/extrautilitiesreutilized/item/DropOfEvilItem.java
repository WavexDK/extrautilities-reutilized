package net.wavedk.extrautilitiesreutilized.item;

import net.minecraft.world.item.Item;

public class DropOfEvilItem extends Item {
	public DropOfEvilItem(Item.Properties properties) {
		super(properties);
	}
}