package net.wavedk.extrautilitiesreutilized.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class EnchantedIngotItem extends Item {
	public EnchantedIngotItem(Item.Properties properties) {
		super(properties.rarity(Rarity.UNCOMMON));
	}
}