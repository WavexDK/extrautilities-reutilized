package net.wavedk.extrautilitiesreutilized.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class MagicalNuggetItem extends Item {
	public MagicalNuggetItem(Item.Properties properties) {
		super(properties.rarity(Rarity.UNCOMMON));
	}
}