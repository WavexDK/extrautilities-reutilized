package net.wavedk.extrautilitiesreutilized.item;

import net.minecraft.world.item.component.Consumables;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;
import net.minecraft.world.food.FoodProperties;

public class EnchantedAppleItem extends Item {
	public EnchantedAppleItem(Item.Properties properties) {
		super(properties.rarity(Rarity.UNCOMMON).food((new FoodProperties.Builder()).nutrition(8).saturationModifier(0.3f).alwaysEdible().build(), Consumables.defaultFood().consumeSeconds(1.2F).build()));
	}
}