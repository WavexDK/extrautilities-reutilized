/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.wavedk.extrautilitiesreutilized.init;

import net.wavedk.extrautilitiesreutilized.block.*;
import net.wavedk.extrautilitiesreutilized.EuruMod;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredBlock;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.Block;

import java.util.function.Function;

public class EuruModBlocks {
	public static final DeferredRegister.Blocks REGISTRY = DeferredRegister.createBlocks(EuruMod.MODID);
	public static final DeferredBlock<Block> SOLAR_PANEL;
	public static final DeferredBlock<Block> LUNAR_PANEL;
	public static final DeferredBlock<Block> RESONATOR;
	public static final DeferredBlock<Block> CHUNK_LOADER;
	public static final DeferredBlock<Block> MACHINE_BLOCK;
	public static final DeferredBlock<Block> SURVIVAL_GENERATOR;
	public static final DeferredBlock<Block> CHUNK_LOADER_TESTER;
	public static final DeferredBlock<Block> GILDED_OBSIDIAN;
	public static final DeferredBlock<Block> ANGEL_BLOCK;
	public static final DeferredBlock<Block> COMPRESSED_COBBLESTONE;
	public static final DeferredBlock<Block> DOUBLE_COMPRESSED_COBBLESTONE;
	public static final DeferredBlock<Block> TRIPLE_COMPRESSED_COBBLESTONE;
	public static final DeferredBlock<Block> QUADRUPLE_COMPRESSED_COBBLESTONE;
	public static final DeferredBlock<Block> QUINTUPLE_COMPRESSED_COBBLESTONE;
	public static final DeferredBlock<Block> SEXTUPLE_COMPRESSED_COBBLESTONE;
	public static final DeferredBlock<Block> SEPTUPLE_COMPRESSED_COBBLESTONE;
	public static final DeferredBlock<Block> OCTUPLE_COMPRESSED_COBBLESTONE;
	public static final DeferredBlock<Block> MANUAL_MILL;
	public static final DeferredBlock<Block> WATER_MILL;
	public static final DeferredBlock<Block> LAVA_MILL;
	public static final DeferredBlock<Block> STONE_BURNT;
	public static final DeferredBlock<Block> FIRE_MILL;
	public static final DeferredBlock<Block> ENCHANTER;
	public static final DeferredBlock<Block> FURNACE_GENERATOR;
	static {
		SOLAR_PANEL = register("solar_panel", SolarPanelBlock::new);
		LUNAR_PANEL = register("lunar_panel", LunarPanelBlock::new);
		RESONATOR = register("resonator", ResonatorBlock::new);
		CHUNK_LOADER = register("chunk_loader", ChunkLoaderBlock::new);
		MACHINE_BLOCK = register("machine_block", MachineBlockBlock::new);
		SURVIVAL_GENERATOR = register("survival_generator", SurvivalGeneratorBlock::new);
		CHUNK_LOADER_TESTER = register("chunk_loader_tester", ChunkLoaderTesterBlock::new);
		GILDED_OBSIDIAN = register("gilded_obsidian", GildedObsidianBlock::new);
		ANGEL_BLOCK = register("angel_block", AngelBlockBlock::new);
		COMPRESSED_COBBLESTONE = register("compressed_cobblestone", CompressedCobblestoneBlock::new);
		DOUBLE_COMPRESSED_COBBLESTONE = register("double_compressed_cobblestone", DoubleCompressedCobblestoneBlock::new);
		TRIPLE_COMPRESSED_COBBLESTONE = register("triple_compressed_cobblestone", TripleCompressedCobblestoneBlock::new);
		QUADRUPLE_COMPRESSED_COBBLESTONE = register("quadruple_compressed_cobblestone", QuadrupleCompressedCobblestoneBlock::new);
		QUINTUPLE_COMPRESSED_COBBLESTONE = register("quintuple_compressed_cobblestone", QuintupleCompressedCobblestoneBlock::new);
		SEXTUPLE_COMPRESSED_COBBLESTONE = register("sextuple_compressed_cobblestone", SextupleCompressedCobblestoneBlock::new);
		SEPTUPLE_COMPRESSED_COBBLESTONE = register("septuple_compressed_cobblestone", SeptupleCompressedCobblestoneBlock::new);
		OCTUPLE_COMPRESSED_COBBLESTONE = register("octuple_compressed_cobblestone", OctupleCompressedCobblestoneBlock::new);
		MANUAL_MILL = register("manual_mill", ManualMillBlock::new);
		WATER_MILL = register("water_mill", WaterMillBlock::new);
		LAVA_MILL = register("lava_mill", LavaMillBlock::new);
		STONE_BURNT = register("stone_burnt", StoneBurntBlock::new);
		FIRE_MILL = register("fire_mill", FireMillBlock::new);
		ENCHANTER = register("enchanter", EnchanterBlock::new);
		FURNACE_GENERATOR = register("furnace_generator", FurnaceGeneratorBlock::new);
	}

	// Start of user code block custom blocks
	// End of user code block custom blocks
	private static <B extends Block> DeferredBlock<B> register(String name, Function<BlockBehaviour.Properties, ? extends B> supplier) {
		return REGISTRY.registerBlock(name, supplier);
	}
}