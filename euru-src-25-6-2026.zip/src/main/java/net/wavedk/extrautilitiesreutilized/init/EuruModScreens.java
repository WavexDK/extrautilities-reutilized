/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.wavedk.extrautilitiesreutilized.init;

import net.wavedk.extrautilitiesreutilized.client.gui.SGenGUIScreen;
import net.wavedk.extrautilitiesreutilized.client.gui.ResonatorGUIScreen;
import net.wavedk.extrautilitiesreutilized.client.gui.FGenGUIScreen;
import net.wavedk.extrautilitiesreutilized.client.gui.EnchanterGUIScreen;
import net.wavedk.extrautilitiesreutilized.client.gui.BagOfHoldingGUIScreen;

import net.neoforged.neoforge.client.event.RegisterMenuScreensEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.api.distmarker.Dist;

@EventBusSubscriber(Dist.CLIENT)
public class EuruModScreens {
	@SubscribeEvent
	public static void clientLoad(RegisterMenuScreensEvent event) {
		event.register(EuruModMenus.RESONATOR_GUI.get(), ResonatorGUIScreen::new);
		event.register(EuruModMenus.S_GEN_GUI.get(), SGenGUIScreen::new);
		event.register(EuruModMenus.BAG_OF_HOLDING_GUI.get(), BagOfHoldingGUIScreen::new);
		event.register(EuruModMenus.ENCHANTER_GUI.get(), EnchanterGUIScreen::new);
		event.register(EuruModMenus.F_GEN_GUI.get(), FGenGUIScreen::new);
	}

	public interface ScreenAccessor {
		void updateMenuState(int elementType, String name, Object elementState);
	}
}