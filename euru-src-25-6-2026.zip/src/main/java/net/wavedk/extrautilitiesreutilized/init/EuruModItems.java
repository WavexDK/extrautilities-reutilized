/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.wavedk.extrautilitiesreutilized.init;

import net.wavedk.extrautilitiesreutilized.item.inventory.BagOfHoldingInventoryCapability;
import net.wavedk.extrautilitiesreutilized.item.*;
import net.wavedk.extrautilitiesreutilized.block.*;
import net.wavedk.extrautilitiesreutilized.EuruMod;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.client.event.RegisterRangeSelectItemModelPropertyEvent;
import net.neoforged.neoforge.capabilities.RegisterCapabilitiesEvent;
import net.neoforged.neoforge.capabilities.Capabilities;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.api.distmarker.Dist;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;
import net.minecraft.resources.ResourceLocation;

import java.util.function.Function;

@EventBusSubscriber
public class EuruModItems {
	public static final DeferredRegister.Items REGISTRY = DeferredRegister.createItems(EuruMod.MODID);
	public static final DeferredItem<Item> SOLAR_PANEL;
	public static final DeferredItem<Item> GP_SCANNER;
	public static final DeferredItem<Item> LUNAR_PANEL;
	public static final DeferredItem<Item> RESONATOR;
	public static final DeferredItem<Item> UPGRADE_BASE;
	public static final DeferredItem<Item> SPEED_UPGRADE;
	public static final DeferredItem<Item> RESONATING_REDSTONE_CRYSTAL;
	public static final DeferredItem<Item> ENDER_SHARD;
	public static final DeferredItem<Item> GLASS_CUTTER;
	public static final DeferredItem<Item> CHUNK_LOADER;
	public static final DeferredItem<Item> MAGICAL_SPEED_UPGRADE;
	public static final DeferredItem<Item> MACHINE_BLOCK;
	public static final DeferredItem<Item> LUNAR_REACTIVE_DUST;
	public static final DeferredItem<Item> SURVIVAL_GENERATOR;
	public static final DeferredItem<Item> CHUNK_LOADER_TESTER;
	public static final DeferredItem<Item> GILDED_OBSIDIAN;
	public static final DeferredItem<Item> NUGGETO_EXPERIENCE;
	public static final DeferredItem<Item> ANGEL_BLOCK;
	public static final DeferredItem<Item> COMPRESSED_COBBLESTONE;
	public static final DeferredItem<Item> DOUBLE_COMPRESSED_COBBLESTONE;
	public static final DeferredItem<Item> TRIPLE_COMPRESSED_COBBLESTONE;
	public static final DeferredItem<Item> QUADRUPLE_COMPRESSED_COBBLESTONE;
	public static final DeferredItem<Item> QUINTUPLE_COMPRESSED_COBBLESTONE;
	public static final DeferredItem<Item> SEXTUPLE_COMPRESSED_COBBLESTONE;
	public static final DeferredItem<Item> SEPTUPLE_COMPRESSED_COBBLESTONE;
	public static final DeferredItem<Item> OCTUPLE_COMPRESSED_COBBLESTONE;
	public static final DeferredItem<Item> MANUAL_MILL;
	public static final DeferredItem<Item> WATER_MILL;
	public static final DeferredItem<Item> REDSTONE_GEAR;
	public static final DeferredItem<Item> GOLDEN_LASSO;
	public static final DeferredItem<Item> LAVA_MILL;
	public static final DeferredItem<Item> STONE_BURNT;
	public static final DeferredItem<Item> CURSED_LASSO;
	public static final DeferredItem<Item> DROP_OF_EVIL;
	public static final DeferredItem<Item> FIRE_MILL;
	public static final DeferredItem<Item> BAG_OF_HOLDING;
	public static final DeferredItem<Item> ENCHANTER;
	public static final DeferredItem<Item> MAGICAL_NUGGET;
	public static final DeferredItem<Item> ENCHANTED_INGOT;
	public static final DeferredItem<Item> ENCHANTED_APPLE;
	public static final DeferredItem<Item> FURNACE_GENERATOR;
	public static final DeferredItem<Item> CHICKEN_RING;
	public static final DeferredItem<Item> SQUID_RING;
	public static final DeferredItem<Item> ANGEL_RING;
	public static final DeferredItem<Item> GOLDEN_LASSO_CW;
	public static final DeferredItem<Item> GOLDEN_LASSO_SW;
	public static final DeferredItem<Item> GOLDEN_LASSO_AR;
	public static final DeferredItem<Item> CURSED_LASSO_AR;
	static {
		SOLAR_PANEL = register("solar_panel", properties -> new SolarPanelBlock.Item(properties.stacksTo(16)));
		GP_SCANNER = register("gp_scanner", GPScannerItem::new);
		LUNAR_PANEL = register("lunar_panel", properties -> new LunarPanelBlock.Item(properties.stacksTo(16)));
		RESONATOR = block(EuruModBlocks.RESONATOR);
		UPGRADE_BASE = register("upgrade_base", UpgradeBaseItem::new);
		SPEED_UPGRADE = register("speed_upgrade", SpeedUpgradeItem::new);
		RESONATING_REDSTONE_CRYSTAL = register("resonating_redstone_crystal", ResonatingRedstoneCrystalItem::new);
		ENDER_SHARD = register("ender_shard", EnderShardItem::new);
		GLASS_CUTTER = register("glass_cutter", GlassCutterItem::new);
		CHUNK_LOADER = block(EuruModBlocks.CHUNK_LOADER, new Item.Properties().stacksTo(1));
		MAGICAL_SPEED_UPGRADE = register("magical_speed_upgrade", MagicalSpeedUpgradeItem::new);
		MACHINE_BLOCK = block(EuruModBlocks.MACHINE_BLOCK);
		LUNAR_REACTIVE_DUST = register("lunar_reactive_dust", LunarReactiveDustItem::new);
		SURVIVAL_GENERATOR = block(EuruModBlocks.SURVIVAL_GENERATOR);
		CHUNK_LOADER_TESTER = register("chunk_loader_tester", ChunkLoaderTesterBlock.Item::new);
		GILDED_OBSIDIAN = block(EuruModBlocks.GILDED_OBSIDIAN);
		NUGGETO_EXPERIENCE = register("nuggeto_experience", NuggetoExperienceItem::new);
		ANGEL_BLOCK = block(EuruModBlocks.ANGEL_BLOCK);
		COMPRESSED_COBBLESTONE = register("compressed_cobblestone", CompressedCobblestoneBlock.Item::new);
		DOUBLE_COMPRESSED_COBBLESTONE = register("double_compressed_cobblestone", DoubleCompressedCobblestoneBlock.Item::new);
		TRIPLE_COMPRESSED_COBBLESTONE = register("triple_compressed_cobblestone", TripleCompressedCobblestoneBlock.Item::new);
		QUADRUPLE_COMPRESSED_COBBLESTONE = register("quadruple_compressed_cobblestone", QuadrupleCompressedCobblestoneBlock.Item::new);
		QUINTUPLE_COMPRESSED_COBBLESTONE = register("quintuple_compressed_cobblestone", QuintupleCompressedCobblestoneBlock.Item::new);
		SEXTUPLE_COMPRESSED_COBBLESTONE = register("sextuple_compressed_cobblestone", SextupleCompressedCobblestoneBlock.Item::new);
		SEPTUPLE_COMPRESSED_COBBLESTONE = register("septuple_compressed_cobblestone", SeptupleCompressedCobblestoneBlock.Item::new);
		OCTUPLE_COMPRESSED_COBBLESTONE = register("octuple_compressed_cobblestone", OctupleCompressedCobblestoneBlock.Item::new);
		MANUAL_MILL = register("manual_mill", properties -> new ManualMillBlock.Item(properties.stacksTo(1)));
		WATER_MILL = register("water_mill", WaterMillBlock.Item::new);
		REDSTONE_GEAR = register("redstone_gear", RedstoneGearItem::new);
		GOLDEN_LASSO = register("golden_lasso", GoldenLassoItem::new);
		LAVA_MILL = register("lava_mill", LavaMillBlock.Item::new);
		STONE_BURNT = block(EuruModBlocks.STONE_BURNT);
		CURSED_LASSO = register("cursed_lasso", CursedLassoItem::new);
		DROP_OF_EVIL = register("drop_of_evil", DropOfEvilItem::new);
		FIRE_MILL = register("fire_mill", FireMillBlock.Item::new);
		BAG_OF_HOLDING = register("bag_of_holding", BagOfHoldingItem::new);
		ENCHANTER = block(EuruModBlocks.ENCHANTER);
		MAGICAL_NUGGET = register("magical_nugget", MagicalNuggetItem::new);
		ENCHANTED_INGOT = register("enchanted_ingot", EnchantedIngotItem::new);
		ENCHANTED_APPLE = register("enchanted_apple", EnchantedAppleItem::new);
		FURNACE_GENERATOR = block(EuruModBlocks.FURNACE_GENERATOR);
		CHICKEN_RING = register("chicken_ring", ChickenRingItem::new);
		SQUID_RING = register("squid_ring", SquidRingItem::new);
		ANGEL_RING = register("angel_ring", AngelRingItem::new);
		GOLDEN_LASSO_CW = register("golden_lasso_cw", GoldenLassoCWItem::new);
		GOLDEN_LASSO_SW = register("golden_lasso_sw", GoldenLassoSWItem::new);
		GOLDEN_LASSO_AR = register("golden_lasso_ar", GoldenLassoARItem::new);
		CURSED_LASSO_AR = register("cursed_lasso_ar", CursedLassoARItem::new);
	}

	// Start of user code block custom items
	// End of user code block custom items
	private static <I extends Item> DeferredItem<I> register(String name, Function<Item.Properties, ? extends I> supplier) {
		return REGISTRY.registerItem(name, supplier, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block) {
		return block(block, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block, Item.Properties properties) {
		return REGISTRY.registerItem(block.getId().getPath(), prop -> new BlockItem(block.get(), prop), properties);
	}

	@SubscribeEvent
	public static void registerCapabilities(RegisterCapabilitiesEvent event) {
		event.registerItem(Capabilities.ItemHandler.ITEM, (stack, context) -> new BagOfHoldingInventoryCapability(stack), BAG_OF_HOLDING.get());
	}

	@EventBusSubscriber(Dist.CLIENT)
	public static class ItemsClientSideHandler {
		@SubscribeEvent
		public static void registerItemModelProperties(RegisterRangeSelectItemModelPropertyEvent event) {
			event.register(ResourceLocation.parse("euru:ender_shard/count"), EnderShardItem.CountProperty.MAP_CODEC);
			event.register(ResourceLocation.parse("euru:golden_lasso/full"), GoldenLassoItem.FullProperty.MAP_CODEC);
			event.register(ResourceLocation.parse("euru:cursed_lasso/full"), CursedLassoItem.FullProperty.MAP_CODEC);
			event.register(ResourceLocation.parse("euru:cursed_lasso_ar/full"), CursedLassoARItem.FullProperty.MAP_CODEC);
		}
	}
}