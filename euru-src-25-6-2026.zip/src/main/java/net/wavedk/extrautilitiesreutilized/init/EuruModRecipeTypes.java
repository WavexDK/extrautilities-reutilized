package net.wavedk.extrautilitiesreutilized.init;

import net.wavedk.extrautilitiesreutilized.jei_recipes.SGenRecipeTypeRecipe;
import net.wavedk.extrautilitiesreutilized.jei_recipes.ResonatorRecipeTypeRecipe;
import net.wavedk.extrautilitiesreutilized.jei_recipes.FGenRecipeTypeRecipe;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.event.OnDatapackSyncEvent;
import net.neoforged.neoforge.client.event.RecipesReceivedEvent;
import net.neoforged.neoforge.client.event.ClientPlayerNetworkEvent;
import net.neoforged.fml.event.lifecycle.FMLConstructModEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.fml.ModList;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.api.distmarker.Dist;

import net.minecraft.world.item.crafting.RecipeType;
import net.minecraft.world.item.crafting.RecipeSerializer;
import net.minecraft.world.item.crafting.RecipeMap;
import net.minecraft.core.registries.BuiltInRegistries;

@EventBusSubscriber
public class EuruModRecipeTypes {
	public static final DeferredRegister<RecipeType<?>> RECIPE_TYPES = DeferredRegister.create(BuiltInRegistries.RECIPE_TYPE, "euru");
	public static final DeferredRegister<RecipeSerializer<?>> SERIALIZERS = DeferredRegister.create(BuiltInRegistries.RECIPE_SERIALIZER, "euru");
	public static RecipeMap recipes = null;

	@SubscribeEvent
	public static void register(FMLConstructModEvent event) {
		IEventBus bus = ModList.get().getModContainerById("euru").get().getEventBus();
		event.enqueueWork(() -> {
			RECIPE_TYPES.register(bus);
			SERIALIZERS.register(bus);
			RECIPE_TYPES.register("resonator_recipe_type", () -> ResonatorRecipeTypeRecipe.Type.INSTANCE);
			SERIALIZERS.register("resonator_recipe_type", () -> ResonatorRecipeTypeRecipe.Serializer.INSTANCE);
			RECIPE_TYPES.register("s_gen_recipe_type", () -> SGenRecipeTypeRecipe.Type.INSTANCE);
			SERIALIZERS.register("s_gen_recipe_type", () -> SGenRecipeTypeRecipe.Serializer.INSTANCE);
			RECIPE_TYPES.register("f_gen_recipe_type", () -> FGenRecipeTypeRecipe.Type.INSTANCE);
			SERIALIZERS.register("f_gen_recipe_type", () -> FGenRecipeTypeRecipe.Serializer.INSTANCE);
		});
	}

	@SubscribeEvent
	public static void syncRecipes(OnDatapackSyncEvent event) {
		event.sendRecipes(ResonatorRecipeTypeRecipe.Type.INSTANCE);
		event.sendRecipes(SGenRecipeTypeRecipe.Type.INSTANCE);
		event.sendRecipes(FGenRecipeTypeRecipe.Type.INSTANCE);
	}

	@EventBusSubscriber(value = Dist.CLIENT)
	public static class RecipeReceiver {
		@SubscribeEvent
		public static void receiveRecipes(RecipesReceivedEvent event) {
			recipes = event.getRecipeMap();
		}

		@SubscribeEvent
		public static void clearRecipes(ClientPlayerNetworkEvent.LoggingOut event) {
			recipes = null;
		}
	}
}