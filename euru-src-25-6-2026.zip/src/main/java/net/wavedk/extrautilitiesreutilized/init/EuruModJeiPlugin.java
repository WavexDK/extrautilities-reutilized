package net.wavedk.extrautilitiesreutilized.init;

import net.wavedk.extrautilitiesreutilized.jei_recipes.*;

import net.minecraft.world.item.crafting.RecipeHolder;
import net.minecraft.world.item.ItemStack;
import net.minecraft.resources.ResourceLocation;

import mezz.jei.api.registration.IRecipeRegistration;
import mezz.jei.api.registration.IRecipeCategoryRegistration;
import mezz.jei.api.registration.IRecipeCatalystRegistration;
import mezz.jei.api.recipe.types.IRecipeType;
import mezz.jei.api.constants.VanillaTypes;
import mezz.jei.api.JeiPlugin;
import mezz.jei.api.IModPlugin;

import java.util.stream.Collectors;
import java.util.List;

@JeiPlugin
public class EuruModJeiPlugin implements IModPlugin {
	public static IRecipeType<ResonatorRecipeTypeRecipe> ResonatorRecipeType_Type = IRecipeType.create(ResonatorRecipeTypeRecipeCategory.UID, ResonatorRecipeTypeRecipe.class);
	public static IRecipeType<SGenRecipeTypeRecipe> SGenRecipeType_Type = IRecipeType.create(SGenRecipeTypeRecipeCategory.UID, SGenRecipeTypeRecipe.class);
	public static IRecipeType<FGenRecipeTypeRecipe> FGenRecipeType_Type = IRecipeType.create(FGenRecipeTypeRecipeCategory.UID, FGenRecipeTypeRecipe.class);

	@Override
	public ResourceLocation getPluginUid() {
		return ResourceLocation.parse("euru:jei_plugin");
	}

	@Override
	public void registerCategories(IRecipeCategoryRegistration registration) {
		registration.addRecipeCategories(new ResonatorRecipeTypeRecipeCategory(registration.getJeiHelpers().getGuiHelper()));
		registration.addRecipeCategories(new SGenRecipeTypeRecipeCategory(registration.getJeiHelpers().getGuiHelper()));
		registration.addRecipeCategories(new FGenRecipeTypeRecipeCategory(registration.getJeiHelpers().getGuiHelper()));
	}

	@Override
	public void registerRecipes(IRecipeRegistration registration) {
		List<ResonatorRecipeTypeRecipe> ResonatorRecipeTypeRecipes = EuruModRecipeTypes.recipes.byType(ResonatorRecipeTypeRecipe.Type.INSTANCE).stream().map(RecipeHolder::value).collect(Collectors.toList());
		registration.addRecipes(ResonatorRecipeType_Type, ResonatorRecipeTypeRecipes);
		List<SGenRecipeTypeRecipe> SGenRecipeTypeRecipes = EuruModRecipeTypes.recipes.byType(SGenRecipeTypeRecipe.Type.INSTANCE).stream().map(RecipeHolder::value).collect(Collectors.toList());
		registration.addRecipes(SGenRecipeType_Type, SGenRecipeTypeRecipes);
		List<FGenRecipeTypeRecipe> FGenRecipeTypeRecipes = EuruModRecipeTypes.recipes.byType(FGenRecipeTypeRecipe.Type.INSTANCE).stream().map(RecipeHolder::value).collect(Collectors.toList());
		registration.addRecipes(FGenRecipeType_Type, FGenRecipeTypeRecipes);
	}

	@Override
	public void registerRecipeCatalysts(IRecipeCatalystRegistration registration) {
		registration.addCraftingStations(ResonatorRecipeType_Type, VanillaTypes.ITEM_STACK, List.of(new ItemStack(EuruModBlocks.RESONATOR.get().asItem())));
		registration.addCraftingStations(SGenRecipeType_Type, VanillaTypes.ITEM_STACK, List.of(new ItemStack(EuruModBlocks.SURVIVAL_GENERATOR.get().asItem())));
		registration.addCraftingStations(FGenRecipeType_Type, VanillaTypes.ITEM_STACK, List.of(new ItemStack(EuruModBlocks.FURNACE_GENERATOR.get().asItem())));
	}
}